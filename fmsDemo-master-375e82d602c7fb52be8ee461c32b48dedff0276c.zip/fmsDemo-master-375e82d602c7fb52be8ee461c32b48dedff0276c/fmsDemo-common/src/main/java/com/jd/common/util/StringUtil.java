package com.jd.common.util;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.builder.ToStringBuilder;

public class StringUtil extends StringUtils {

	public static String toObjString(Object... obj) {
		return ToStringBuilder.reflectionToString(obj);
	}
	public static String toPath(String... paths) {
		boolean first = true;
		StringBuilder sb = new StringBuilder();
		for (String path : paths) {
			if (first) {
				first = false;
			} else {
				sb.append("/");
			}
			sb.append(path);
		}
		return sb.toString();
	}
}
