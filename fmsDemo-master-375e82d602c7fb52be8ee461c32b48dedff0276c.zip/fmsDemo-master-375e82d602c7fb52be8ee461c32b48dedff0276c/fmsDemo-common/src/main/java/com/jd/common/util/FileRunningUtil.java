package com.jd.common.util;

import java.io.File;
import java.util.List;

/**
 * 通过修改文件名后续标志预占读取文件工具类
 */
public class FileRunningUtil {

	private static String runningFlag = "_running";
	private static String endFlag = "_end";
	private static String tarFlag = ".tar";
	private static String bakFolder = "_bak";

	public static boolean checkExists(File sourceFile) {
		boolean exists = false;
		if (sourceFile != null) {
			exists = exists || sourceFile.exists();
			exists = exists || (new File(sourceFile.getParent() + "/" + bakFolder + "/" + sourceFile.getName() + endFlag)).exists();
			exists = exists || (new File(sourceFile.getAbsolutePath() + runningFlag)).exists();
		}
		return exists;
	}

	public static File getExistsFile(String fileFullName) {
		File file = new File(fileFullName);
		if (file.exists()) {
			return file;
		} else {
			return null;
		}
	}

	public static File removeNameRunning(File sourceFile) {
		File reNameFile = new File(sourceFile.getParent() + "/" + sourceFile.getName().replace(runningFlag, ""));
		sourceFile.renameTo(reNameFile);
		return reNameFile;
	}

	public static File addNameRunning(File sourceFile) {
		File reNameFile = new File(sourceFile.getAbsoluteFile() + runningFlag);
		sourceFile.renameTo(reNameFile);
		return reNameFile;
	}

	public static File addNameEnd(File sourceFile) {
		File bakFold = new File(sourceFile.getParent() + "/" + bakFolder);
		if (bakFold.exists() == false) {
			bakFold.mkdirs();
		}
		File reNameFile = new File(bakFold.getAbsolutePath() + "/" + sourceFile.getName().replaceAll(runningFlag, "")
				+ endFlag);
		sourceFile.renameTo(reNameFile);
		return reNameFile;
	}
	public static File removeNameEnd(File sourceFile) {
		if (sourceFile.getParentFile().exists() == false) {
			sourceFile.getParentFile().mkdirs();
		}
		File reNameFile = new File(sourceFile.getParentFile().getParentFile().getAbsolutePath() + "/" + sourceFile.getName().replaceAll(endFlag, ""));
		sourceFile.renameTo(reNameFile);
		return reNameFile;
	}

	public static void trans(File sourceFile, List<File> refFiles) {
		String name = sourceFile.getName();
		// 排除特定后缀[执行中，或者执行完毕的文件]
		if (canPass(name)) {
			return;
		}
		if (sourceFile != null) {
			if (sourceFile.isDirectory()) {
				File[] listFiles = sourceFile.listFiles();
				for (File file : listFiles) {
					trans(file, refFiles);
				}
			} else if (sourceFile.exists()) {
				File running = addNameRunning(sourceFile);
				if (running.exists()) {
					refFiles.add(running);
				}
			}
		}
	}

	private static boolean canPass(String fileName) {
		return fileName.indexOf(runningFlag) != -1 || fileName.indexOf(endFlag) != -1 || fileName.equals(bakFolder)
				|| fileName.indexOf(tarFlag) != -1;
	}
}
