package com.jd.common.util;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.ChannelSftp.LsEntry;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.UserInfo;

public class SFtpUtil {
	/**
	 * 日志
	 */
	private final static Logger logger = LoggerFactory.getLogger(SFtpUtil.class);
	/** 分隔符 */
	protected final static String SEPARATOR = "/";

	public static class MyUserInfo implements UserInfo {

		private String passphrase = null;

		public MyUserInfo(String passphrase) {
			this.passphrase = passphrase;
		}

		public String getPassphrase() {
			return passphrase;
		}

		public String getPassword() {
			return null;
		}

		public boolean promptPassphrase(String s) {
			return true;
		}

		public boolean promptPassword(String s) {
			return true;
		}

		public boolean promptYesNo(String s) {
			return true;
		}

		public void showMessage(String s) {
		}
	}

	public static class SftpClient {
		/** 客户端 */
		private JSch jsch = null;
		private Session session = null;
		private ChannelSftp sftpChannel = null;
		private int loginType = 0; // 0-用户名密码方式访问, 1-公钥私钥(+私钥密码)方式访问
		/** 本地服务器信息：私钥 --- 如果不用公钥私钥，可以不用设置 */
		private String keyfile;
		/** 本地服务器信息：私钥密码 --- 如果不用公钥私钥，可以不用设置 */
		private String passphrase;
		/** 是否已经连接 */
		private boolean connected = false;
		/** 远程服务器信息：IP地址 */
		private String ip;
		/** 远程服务器信息：端口 */
		private int port;
		/** 远程服务器信息：用户名 */
		private String username;
		/** 远程服务器信息：密码 */
		private String password;

		/**
		 * 构造方法
		 */
		public SftpClient() {
			jsch = new JSch();
		}

		/**
		 * 连接sftp
		 * 
		 * @param ip
		 *            服务器地址
		 * @param port
		 *            服务器端口
		 * @param username
		 *            用户名
		 * @param password
		 *            密码
		 * @throws SftpException
		 * @return 连接成功与否
		 */
		public boolean connect(String ip, int port, String username, String password) throws SftpException {
			this.ip = ip;
			this.port = port;
			this.username = username;
			this.password = password;
			this.loginType = 0;
			return connect();
		}

		/**
		 * 连接sftp
		 * 
		 * @param ip
		 *            服务器地址
		 * @param port
		 *            服务器端口
		 * @param username
		 *            用户名
		 * @param keyfile
		 *            私钥文件（绝对路径）
		 * @param passphrase
		 *            密码
		 * @throws SftpException
		 * @return 连接成功与否
		 */
		public boolean connect(String ip, int port, String username, String keyfile, String passphrase) throws SftpException {
			this.ip = ip;
			this.port = port;
			this.username = username;
			this.keyfile = keyfile;
			this.passphrase = passphrase;
			this.loginType = 1;
			return connect();
		}

		/**
		 * 连接情况
		 * 
		 * @return 连接成功与否
		 * @throws SftpException
		 */
		public boolean connect() throws SftpException {
			logger.info("username:" + username + ";ip:" + ip + ":" + port + ";keyfile:" + keyfile);
			try {
				if (loginType == 0) {
					session = jsch.getSession(username, ip, port);
					session.setConfig("StrictHostKeyChecking", "no");
					session.setPassword(password);
				} else if (loginType == 1) {
					jsch.addIdentity(keyfile);
					session = jsch.getSession(username, ip, port);
					UserInfo ui = new MyUserInfo(passphrase);
					session.setUserInfo(ui);
				}
				session.connect(30000);// 设置超时时间
				Channel channel = session.openChannel("sftp");
				channel.connect();
				sftpChannel = (ChannelSftp) channel;
				connected = true;
			} catch (JSchException e) {
				connected = false;
				logger.error("连接SFTP服务器出现异常", e);
				throw new SftpException(port, ip, e);
			}
			return connected;
		}

		/**
		 * 断开连接
		 * 
		 * @throws SftpException
		 */
		public void disconnect() {
			if (session.isConnected()) {
				session.disconnect();
			}
			if (sftpChannel.isConnected()) {
				sftpChannel.disconnect();
			}
			connected = false;
		}

		/**
		 * 是否连接
		 * 
		 * @return
		 */
		public boolean isConnected() {
			return connected && session.isConnected() && sftpChannel.isConnected();
		}

		public ChannelSftp getSftpChannel() {
			return sftpChannel;
		}
	}

	public static SftpClient getOpenClient(String ip, int port, String username, String password) throws SftpException {
		SftpClient client = new SftpClient();
		if (client.connect(ip, port, username, password)) {
			return client;
		}
		return null;
	}

	/**
	 * 连接sftp
	 * 
	 * @param ip
	 *            服务器地址
	 * @param port
	 *            服务器端口
	 * @param username
	 *            用户名
	 * @param keyfile
	 *            私钥文件（绝对路径）
	 * @param passphrase
	 *            密码
	 * @throws SftpException
	 */
	public static SftpClient getOpenClient(String ip, int port, String username, String keyfile, String passphrase) throws SftpException {
		SftpClient client = new SftpClient();
		if (client.connect(ip, port, username, keyfile, passphrase)) {
			return client;
		}
		return null;
	}

	/**
	 * 下载单个文件到本地
	 * 
	 * @param remoteFilePath
	 *            远程地址(sftp全路径)
	 * @param localFilePath
	 *            本地地址(绝对路径)
	 * @param overwrite
	 *            是否覆盖本地文件
	 * @return 下载情况
	 */
	public static boolean download(SftpClient sc, String remotePath, String fileName, String localFilePath, boolean overwrite) {
		try {
			// 先连接下
			if (!sc.isConnected()) {
				if (!sc.connect()) {
					return false;
				}
			}
			File localFile = new File(localFilePath);
			String remotefileName = remotePath + fileName;
			if (localFile.isDirectory()) {
				localFile = new File(localFilePath + fileName);
			}
			if (localFile.exists()) {
				logger.debug("本地文件已存在:{}-->{}", remotefileName, localFilePath);
				if (!overwrite) { // 不覆盖
					logger.debug("SFTP 下载不覆盖:{}-->{}", remotefileName, localFilePath);
					return true;
				}
			}
			// 下载文件
			sc.getSftpChannel().get(remotefileName, localFilePath);
			logger.info("SFTP下载文件完成: {} --> {} ", remotefileName, localFilePath);
			return true;
		} catch (Exception e) {
			logger.error("SFTP下载文件异常", e);
		}
		return false;
	}

	/**
	 * 下载单个文件到本地
	 * 
	 * @param remoteFolderPath
	 *            远程地址(sftp全路径)
	 * @param localFolderPath
	 *            本地地址(绝对路径)
	 * @return
	 * @return 下载情况
	 */
	public static boolean downloadFolder(SftpClient sc, String remoteFolderPath, String localFolderPath, boolean recursive, boolean overwrite) {
		try {
			// 先连接下
			if (!sc.isConnected()) {
				if (!sc.connect()) {
					return false;
				}
			}
			ChannelSftp sftpChannel = sc.getSftpChannel();
			remoteFolderPath = avoidFolderHead(avoidFolderEnd(remoteFolderPath));
			localFolderPath = avoidFolderEnd(localFolderPath);
			logger.info("SFTP开始下载文件夹:{}-->{}", remoteFolderPath, localFolderPath);
			Vector vFileList = sftpChannel.ls(remoteFolderPath);
			for (Object object : vFileList) {
				LsEntry l = (LsEntry) object;
				SftpATTRS t = sftpChannel.lstat(remoteFolderPath + l.getFilename());
				if (".".equals(l.getFilename()) || "..".equals(l.getFilename())) {
					continue;
				}
				if (t.isDir()) {
					File localFolder = new File(localFolderPath + l.getFilename());
					if (!localFolder.exists()) {
						localFolder.mkdirs();
					}
					if (recursive) {
						downloadFolder(sc, remoteFolderPath + l.getFilename(), localFolder.getAbsolutePath(), recursive, overwrite);
					}
				} else {
					download(sc, remoteFolderPath, l.getFilename(), localFolderPath, overwrite);
				}
			}
			logger.info("SFTP下载文件完成: {} --> {} ", remoteFolderPath, localFolderPath);
			return true;
		} catch (SftpException e) {
			logger.error("SFTP下载文件异常", e);
		}
		return false;
	}

	/**
	 * SFTP下是否存在该文件
	 * 
	 * @param path
	 *            文件路径
	 * @return 是否存在
	 * @throws SftpException
	 * @throws SftpException
	 */
	public static boolean exists(SftpClient sc, String path) throws SftpException {
		if (!sc.isConnected()) {
			if (!sc.connect()) {
				return false;
			}
		}
		Vector ls = sc.getSftpChannel().ls(path);
		return ls != null && ls.size() == 1;
	}

	/**
	 * SFTP下文件列表
	 * 
	 * @param path
	 *            文件路径
	 * @return 是否存在
	 * @throws SftpException
	 * @throws SftpException
	 */
	public static List<String> ls(SftpClient sc, String path) throws SftpException {
		if (!sc.isConnected()) {
			sc.connect();
		}
		List<String> rs = new ArrayList<String>();
		Vector<LsEntry> ls = sc.getSftpChannel().ls(path);
		for (LsEntry l : ls) {
			if (".".equals(l.getFilename()) || "..".equals(l.getFilename())) {
				continue;
			}
			rs.add(l.getFilename());
		}
		return rs;
	}

	/**
	 * SFTP下文件列表
	 * 
	 * @param path
	 *            文件路径
	 * @return 是否存在
	 * @throws SftpException
	 * @throws SftpException
	 */
	public static boolean del(SftpClient sc, String path) {
		try {
			if (!sc.isConnected()) {
				sc.connect();
			}
			sc.getSftpChannel().rm(path);
			return true;
		} catch (SftpException e) {
			logger.error("SFTPdel文件异常:" + path, e);
		}
		return false;
	}

	/**
	 * 上传单个文件到远程服务器
	 * 
	 * @param localFilePath
	 *            本地地址
	 * @param remoteFilePath
	 *            远程地址
	 * @return 下载情况
	 */
	public boolean upload(SftpClient sc, String localFilePath, String remoteFilePath, boolean overwrite) {
		try {
			if (!sc.isConnected()) {
				if (!sc.connect()) {
					return false;
				}
			}
			// 本地文件不存在
			if (!new File(localFilePath).exists()) {
				return false;
			}
			// 上传文件
			sc.getSftpChannel().put(localFilePath, remoteFilePath);
			logger.info("SFTP上传文件完成: {} --> {} ", localFilePath, remoteFilePath);
		} catch (Exception e) {
			logger.error("SFTP上传文件异常:" + remoteFilePath, e);
			return false;
		}
		return true;
	}

	/**
	 * 保证文件夹地址最后以分隔符结尾
	 * 
	 * @param folderPath
	 *            地址
	 * @return 文件路径
	 */
	private static String avoidFolderEnd(String folderPath) {
		folderPath = folderPath.replace("\\", SEPARATOR).replace("//", SEPARATOR);
		folderPath = folderPath.endsWith(SEPARATOR) ? folderPath : folderPath + SEPARATOR;
		return folderPath;
	}

	/**
	 * 保证文件夹地址不以分隔符开头
	 * 
	 * @param folderPath
	 *            地址
	 * @return 文件路径
	 */
	private static String avoidFolderHead(String folderPath) {
		folderPath = folderPath.replace("\\", SEPARATOR).replace("//", SEPARATOR);
		return folderPath.startsWith(SEPARATOR) ? folderPath.substring(1) : folderPath;
	}

	public static void main(String[] args) throws SftpException {
		String ip = "10.16.253.174";
		int port = 22;
		String username = "jingdong";
		String keyfile = "/home/mis/.ssh/id_rsa";
		String passphrase = "";

		String remoteFile2 = "hhap/in/";
		String localFile2 = "/home/mis/gateway/testpgp/boc/bankfile/";

		SftpClient c = getOpenClient(ip, port, username, keyfile, passphrase);
		try {
			downloadFolder(c, remoteFile2, localFile2, true, false);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			c.disconnect();
		}
	}

}
