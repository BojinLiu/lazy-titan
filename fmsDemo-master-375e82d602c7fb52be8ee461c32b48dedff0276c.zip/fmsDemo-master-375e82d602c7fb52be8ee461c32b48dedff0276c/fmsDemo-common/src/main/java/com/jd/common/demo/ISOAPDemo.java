package com.jd.common.demo;

import javax.jws.WebParam;
import javax.jws.WebService;

import com.jd.common.demo.webbean.WebDemoItem;

@WebService(targetNamespace = "http://www.360buy.com")
public interface ISOAPDemo {

	public String select(@WebParam(name = "orderId") String orderId);
	public WebDemoItem selectRefundMoney(@WebParam(name = "orderId") String orderId);
}
