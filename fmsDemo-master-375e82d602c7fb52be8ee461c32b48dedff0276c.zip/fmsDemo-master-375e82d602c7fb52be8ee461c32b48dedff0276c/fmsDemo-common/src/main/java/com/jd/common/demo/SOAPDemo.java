package com.jd.common.demo;

import javax.jws.WebParam;
import javax.jws.WebService;

import org.apache.log4j.Logger;

import com.jd.common.demo.webbean.WebDemoItem;
import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

/**
 * Created by IntelliJ IDEA. User: ljt Date: 2011-8-11 Time: 10:56:19 To change
 * this template use File | Settings | File Templates.
 */
@WebService(endpointInterface = "com.jd.common.demo.ISOAPDemo")
public class SOAPDemo implements ISOAPDemo {

	protected Logger log = Logger.getLogger(getClass());

	public String select(@WebParam(name = "orderId") String orderId) {
		// 统一监控
		CallerInfo info = Profiler.registerInfo("fms.posWebservice.selectRefundOrderId.execute",true,true);
		Profiler.registerInfoEnd(info);
		return "false";
	}

	@Override
	public WebDemoItem selectRefundMoney(String orderId) {
		// 统一监控
		CallerInfo info = Profiler.registerInfo("fms.posWebservice.selectRefundMoney.execute",true,true);
		Profiler.registerInfoEnd(info);
		return null;
	}

}
