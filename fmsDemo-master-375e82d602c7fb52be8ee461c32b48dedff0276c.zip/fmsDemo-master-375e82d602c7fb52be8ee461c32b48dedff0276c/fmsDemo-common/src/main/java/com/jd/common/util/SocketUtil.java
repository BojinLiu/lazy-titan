package com.jd.common.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.InetSocketAddress;
import java.net.Socket;

/**
 * 
 * @since 2010-11-24
 * @version 1.0v
 */
public class SocketUtil {

	public static void main(String[] args) throws IOException {
		String send = SocketUtil.send("192.168.157.34", 11000, 1000, getRequest("def obj = \"汉字\"; return obj;", "UTF-8"), "UTF-8");
		System.out.println("send=" + send);
	}
	
	private static String getRequest(String source, String encode) throws UnsupportedEncodingException {
		byte[] bytes = source.getBytes(encode);
		return String.format("%08d", bytes.length) + source;
	}
	
	public static String send(String addr, int port, int timeout, String request, String encode) throws IOException {
		Socket client = new Socket();
		String rt = null;
		try {
			client.connect(new InetSocketAddress(addr, port), timeout);
			client.setSoTimeout(timeout);
			InputStream in = null;
			OutputStream out = null;
			ByteArrayOutputStream data = null;
			try {
				in = client.getInputStream();
				out = client.getOutputStream();
				out.write(getRequest(request, encode).getBytes(encode));
				out.flush();
				data = new ByteArrayOutputStream();
				byte[] bs = new byte[1024];
				int end = 0;
				while ((end = in.read(bs)) != -1) {
					data.write(bs, 0, end);
				}
				rt = new String(data.toByteArray(), encode);
			} finally {
				if (data != null) {
					data.close();
				}
				if (out != null) {
					out.close();
				}
				if (in != null) {
					in.close();
				}
			}
		} finally {
			if (client != null) {
				client.close();
			}
		}
		return rt;
	}
}