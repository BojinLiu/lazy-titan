package com.jd.common.demo.webbean;

import javax.xml.bind.annotation.XmlElement;

public class WebDemoItemWrap {
	
	@XmlElement(name = "info")
	public WebDemoItem info;
}
