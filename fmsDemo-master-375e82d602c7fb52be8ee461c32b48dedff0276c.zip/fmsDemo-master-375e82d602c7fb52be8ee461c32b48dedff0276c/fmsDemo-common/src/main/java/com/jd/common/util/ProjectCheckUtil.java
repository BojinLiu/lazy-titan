package com.jd.common.util;

import java.io.File;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;
import org.apache.cxf.frontend.ClientProxyFactoryBean;
import org.springframework.context.ApplicationContext;

import com.jd.common.domain.FtpInfoBean;

public class ProjectCheckUtil {

	private static HttpClient hc = new HttpClient();
	private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	public static void main(String[] args) {
		// System.out.println(checkWsClient("http://www.baidu.com/"));
		List<String> listNewFile = listNewFile("D:/tmp");
		for (String fileName : listNewFile) {
			System.out.println(fileName);
		}
	}
	
	//todo:增加校验验证结论jdk7+sqlserver-jdbc-3.0会导致date类型的解析时间错误，导致显示时间向前两天的问题
	/**
	 * 校验jdk版本和sqlserver 驱动版本是否兼容
	 * 罗金
	 * @return
	 */
	private static boolean checkSqlServerDriver() {
		Class clazz=null;
		try {
			clazz=Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		} catch (ClassNotFoundException e) {
			return true;
		}
		String path = clazz.getProtectionDomain().getCodeSource().getLocation().getPath();
		String dbVerStr = path.substring(path.lastIndexOf("\\"), path.length()).replace("\\", "").trim();
		double dbVer = Double.parseDouble(dbVerStr);
		if(dbVer<4.0){
			String jdkVerStr = System.getProperty("java.version").substring(0,3);
			if(Double.parseDouble(jdkVerStr)>=1.7){
				return false;
			}
		}
		return true;
	}
	//todo:增加校验验证@responsebody,由于客户端主动断开导致服务端死循环

	/**
	 * 校验总方法
	 */
	public static List<String> check() {
		List<String> checks = new ArrayList<String>();
		checks.add(getTille());
		ApplicationContext context = ApplicationContextUtil.getContext();
		if (context == null) {
			checks.add("自检无法获取spring句柄，无法自检，请配置<bean class=\"com.jd.common.util.ApplicationContextUtil\" />");
		} else {
			// 校验ftp连接情况
			checks.add("ftp连接服务自检");
			Map<String, FtpInfoBean> beansOfType = context.getBeansOfType(FtpInfoBean.class);
			Set<Entry<String, FtpInfoBean>> entrySet = beansOfType.entrySet();
			for (Entry<String, FtpInfoBean> entry : entrySet) {
				checks.add("[" + toResult(checkFtp(entry.getValue())) + "]FTP服务[" + entry.getKey() + "]校验");
			}
			// 校验webservice依赖情况
			checks.add("依赖webservice服务[cxf]自检");
			Map<String, ClientProxyFactoryBean> fbm = context.getBeansOfType(ClientProxyFactoryBean.class);
			for (ClientProxyFactoryBean factoryBean : fbm.values()) {
				String url = factoryBean.getAddress() + "?wsdl";
				checks.add("[" + toResult(checkWsClient(url)) + "]WS服务[" + url + "]校验");
			}
		}
		// 当天上线文件自检
		String path = ProjectCheckUtil.class.getClassLoader().getResource("").getPath();
		checks.add("当天上线文件自检");
		int li = path.lastIndexOf("WEB-INF/classes/");
		if (li != -1) {
			path = path.substring(0, path.lastIndexOf("WEB-INF/classes/"));
		}
		List<String> listNewFile = listNewFile(path);
		checks.addAll(listNewFile);
		checks.add("sqlserver驱动版本与jdk版本兼容性检测"+toResult(checkSqlServerDriver()));
		return checks;
	}

	public static String getTille() {
		String path = ProjectCheckUtil.class.getClassLoader().getResource("").getPath();
		Pattern p1 = Pattern.compile(".*/(.*?)/.*?/classes.*");
		Matcher matcher = p1.matcher(path);
		String localApp;
		if (matcher.find()) {
			localApp = matcher.group(1);
		} else {
			localApp = path;
		}
		return "应用[" + getLocalIp() + "][" + localApp + "]服务自检信息";
	}

	private static String toResult(Boolean b) {
		if (b == true) {
			return "通过";
		} else {
			return "异常";
		}
	}

	/**
	 * 校验wsdl
	 * 
	 * @param url
	 * @return
	 */
	public static boolean checkWsClient(String url) {
		hc.getParams().setIntParameter("http.socket.timeout", 15000); // 这里的超时单位是毫秒。
		GetMethod getMethod = new GetMethod(url);
		try {
			int statusCode = hc.executeMethod(getMethod);
			if (statusCode == HttpStatus.SC_OK) {
				return true;
			}
		} catch (Throwable e) {
		} finally {
			try {
				getMethod.releaseConnection();
			} catch (Throwable e) {
			}
		}
		return false;
	}

	/**
	 * 列出本日修改的上线文件列表
	 * 
	 * @param rootPath
	 * @return
	 */
	public static List<String> listNewFile(String rootPath) {
		List<String> news = new ArrayList<String>();
		sunListNewFile(new File(rootPath), news, new Date());
		return news;
	}

	private static void sunListNewFile(File subRoot, List<String> news, Date checkDay) {
		if (subRoot == null) {
			return;
		}
		if (subRoot.isFile()) {
			Date fileDate = new Date(subRoot.lastModified());
			if (DateUtils.isSameDay(checkDay, fileDate)) {
				news.add(subRoot.getName() + "[" + sdf.format(fileDate) + "]");
			}
		} else {
			for (File sub : subRoot.listFiles()) {
				sunListNewFile(sub, news, checkDay);
			}
		}
	}

	/**
	 * 校验ftp连接是否正常
	 * 
	 * @param ftpInfo
	 * @return
	 */
	public static boolean checkFtp(FtpInfoBean ftpInfo) {
		// 创建FTPClient对象
		FTPClient ftp = new FTPClient();
		try {
			// 连接FTP服务器
			ftp.connect(ftpInfo.getUrl(), ftpInfo.getPort());
			// 登录ftp
			ftp.login(ftpInfo.getUserName(), ftpInfo.getPassWord());
			// 看返回的值是不是230，如果是，表示登陆成功
			// 以2开头的返回值就会为真
			if (FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
				if (ftp.changeWorkingDirectory(ftpInfo.getRemotePath())) {
					return true;
				}
			}
		} catch (Throwable e) {
		} finally {
			try {
				ftp.logout();
			} catch (Throwable e) {
			}
		}
		return false;
	}

	private static String getLocalIp() {
		try {
			InetAddress ip = null;
			boolean bFindIP = false;
			Enumeration<NetworkInterface> netInterfaces = NetworkInterface.getNetworkInterfaces();
			while (netInterfaces.hasMoreElements()) {
				if (bFindIP) {
					break;
				}
				NetworkInterface ni = netInterfaces.nextElement();
				// ----------特定情况，可以考虑用ni.getName判断
				// 遍历所有ip
				Enumeration<InetAddress> ips = ni.getInetAddresses();
				while (ips.hasMoreElements()) {
					ip = (InetAddress) ips.nextElement();
					if (ip.isSiteLocalAddress() && !ip.isLoopbackAddress() // 127.开头的都是lookback地址
							&& ip.getHostAddress().indexOf(":") == -1) {
						bFindIP = true;
						break;
					}
				}
			}
			return ip.getHostAddress();
		} catch (Throwable e) {
			return "";
		}
	}
}
