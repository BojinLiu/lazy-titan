package com.jd.common.util;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

/**
 * <pre>
 * Title: DES
 * Description: DES加密算法
 * </pre>
 * 
 * @author {开发人员姓名} (mailto:)
 * @version 1.00.00
 * 
 */
/*
 * 修改历史 $log$
 */
public class DesUtil {
	private static final int[] InitialTr = { 58, 50, 42, 34, 26, 18, 10, 2, 60, 52, 44, 36, 28, 20, 12, 4, 62, 54, 46,
			38, 30, 22, 14, 6, 64, 56, 48, 40, 32, 24, 16, 8, 57, 49, 41, 33, 25, 17, 9, 1, 59, 51, 43, 35, 27, 19, 11,
			3, 61, 53, 45, 37, 29, 21, 13, 5, 63, 55, 47, 39, 31, 23, 15, 7 };

	private static final int[] FinalTr = { 40, 8, 48, 16, 56, 24, 64, 32, 39, 7, 47, 15, 55, 23, 63, 31, 38, 6, 46, 14,
			54, 22, 62, 30, 37, 5, 45, 13, 53, 21, 61, 29, 36, 4, 44, 12, 52, 20, 60, 28, 35, 3, 43, 11, 51, 19, 59, 27,
			34, 2, 42, 10, 50, 18, 58, 26, 33, 1, 41, 9, 49, 17, 57, 25 };

	private static final int[] KeyTr1 = { 57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35,
			27, 19, 11, 3, 60, 52, 44, 36, 63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37,
			29, 21, 13, 5, 28, 20, 12, 4 };

	private static final int[] KeyTr2 = { 14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10, 23, 19, 12, 4, 26, 8, 16, 7, 27,
			20, 13, 2, 41, 52, 31, 37, 47, 55, 30, 40, 51, 45, 33, 48, 44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32 };

	private static final int[] Etr = { 32, 1, 2, 3, 4, 5, 4, 5, 6, 7, 8, 9, 8, 9, 10, 11, 12, 13, 12, 13, 14, 15, 16,
			17, 16, 17, 18, 19, 20, 21, 20, 21, 22, 23, 24, 25, 24, 25, 26, 27, 28, 29, 28, 29, 30, 31, 32, 1 };

	private static final int[] Ptr = { 16, 7, 20, 21, 29, 12, 28, 17, 1, 15, 23, 26, 5, 18, 31, 10, 2, 8, 24, 14, 32,
			27, 3, 9, 19, 13, 30, 6, 22, 11, 4, 25 };

	private static final int[][] S = {
			{ 14, 4, 13, 1, 2, 15, 11, 8, 3, 10, 6, 12, 5, 9, 0, 7, 0, 15, 7, 4, 14, 2, 13, 1, 10, 6, 12, 11, 9, 5, 3,
					8, 4, 1, 14, 8, 13, 6, 2, 11, 15, 12, 9, 7, 3, 10, 5, 0, 15, 12, 8, 2, 4, 9, 1, 7, 5, 11, 3, 14, 10,
					0, 6, 13 },
			{ 15, 1, 8, 14, 6, 11, 3, 4, 9, 7, 2, 13, 12, 0, 5, 10, 3, 13, 4, 7, 15, 2, 8, 14, 12, 0, 1, 10, 6, 9, 11,
					5, 0, 14, 7, 11, 10, 4, 13, 1, 5, 8, 12, 6, 9, 3, 2, 15, 13, 8, 10, 1, 3, 15, 4, 2, 11, 6, 7, 12, 0,
					5, 14, 9 },
			{ 10, 0, 9, 14, 6, 3, 15, 5, 1, 13, 12, 7, 11, 4, 2, 8, 13, 7, 0, 9, 3, 4, 6, 10, 2, 8, 5, 14, 12, 11, 15,
					1, 13, 6, 4, 9, 8, 15, 3, 0, 11, 1, 2, 12, 5, 10, 14, 7, 1, 10, 13, 0, 6, 9, 8, 7, 4, 15, 14, 3, 11,
					5, 2, 12 },
			{ 7, 13, 14, 3, 0, 6, 9, 10, 1, 2, 8, 5, 11, 12, 4, 15, 13, 8, 11, 5, 6, 15, 0, 3, 4, 7, 2, 12, 1, 10, 14,
					9, 10, 6, 9, 0, 12, 11, 7, 13, 15, 1, 3, 14, 5, 2, 8, 4, 3, 15, 0, 6, 10, 1, 13, 8, 9, 4, 5, 11, 12,
					7, 2, 14 },
			{ 2, 12, 4, 1, 7, 10, 11, 6, 8, 5, 3, 15, 13, 0, 14, 9, 14, 11, 2, 12, 4, 7, 13, 1, 5, 0, 15, 10, 3, 9, 8,
					6, 4, 2, 1, 11, 10, 13, 7, 8, 15, 9, 12, 5, 6, 3, 0, 14, 11, 8, 12, 7, 1, 14, 2, 13, 6, 15, 0, 9,
					10, 4, 5, 3 },
			{ 12, 1, 10, 15, 9, 2, 6, 8, 0, 13, 3, 4, 14, 7, 5, 11, 10, 15, 4, 2, 7, 12, 9, 5, 6, 1, 13, 14, 0, 11, 3,
					8, 9, 14, 15, 5, 2, 8, 12, 3, 7, 0, 4, 10, 1, 13, 11, 6, 4, 3, 2, 12, 9, 5, 15, 10, 11, 14, 1, 7, 6,
					0, 8, 13 },
			{ 4, 11, 2, 14, 15, 0, 8, 13, 3, 12, 9, 7, 5, 10, 6, 1, 13, 0, 11, 7, 4, 9, 1, 10, 14, 3, 5, 12, 2, 15, 8,
					6, 1, 4, 11, 13, 12, 3, 7, 14, 10, 15, 6, 8, 0, 5, 9, 2, 6, 11, 13, 8, 1, 4, 10, 7, 9, 5, 0, 15, 14,
					2, 3, 12 },
			{ 13, 2, 8, 4, 6, 15, 11, 1, 10, 9, 3, 14, 5, 0, 12, 7, 1, 15, 13, 8, 10, 3, 7, 4, 12, 5, 6, 11, 0, 14, 9,
					2, 7, 11, 4, 1, 9, 12, 14, 2, 0, 6, 10, 13, 15, 3, 5, 8, 2, 1, 14, 7, 4, 10, 8, 13, 15, 12, 9, 0, 3,
					5, 6, 11 } };

	private static final int[] Rots = { 1, 1, 2, 2, 2, 2, 2, 2, 1, 2, 2, 2, 2, 2, 2, 1 };

	private static final void SVC_HEX_2_BIT(byte[] inText, int[] outText, int count) {
		int i, j;
		for (i = 0; i < count; i++)
			for (j = 0; j < 8; j++)
				outText[i * 8 + j] = (inText[i] >> (7 - j)) & 0x01;
	}

	private static final void SVC_BIT_2_HEX(int[] inText, byte[] outText, int count) {
		int i, j;
		for (i = 0; i < count; i++) {
			outText[i] = 0;
			for (j = 0; j < 8; j++)
				outText[i] += inText[i * 8 + j] << (7 - j);
		}
	}

	private static final void transpose(int[] data, int[] tr, int n) {
		int i, k;
		int[] temp = new int[64];
		for (i = 0; i < n; i++) {
			k = tr[i] - 1;
			temp[i] = data[k];
		}
		for (i = 0; i < n; i++)
			data[i] = temp[i];
	}

	private static final void xchange(int[] a) {
		int i, aa;
		for (i = 0; i < 32; i++) {
			aa = a[i];
			a[i] = a[i + 32];
			a[i + 32] = aa;
		}
	}

	private static final void rotateleft(int[] key) {
		int i, aa;
		aa = key[0];
		for (i = 0; i < 27; i++)
			key[i] = key[i + 1];
		key[27] = aa;
		aa = key[28];
		for (i = 28; i < 55; i++)
			key[i] = key[i + 1];
		key[55] = aa;
	}

	private static final void rotateright(int[] key) {
		int i, aa;
		aa = key[55];
		for (i = 55; i > 28; i--)
			key[i] = key[i - 1];
		key[28] = aa;
		aa = key[27];
		for (i = 27; i > 0; i--)
			key[i] = key[i - 1];
		key[0] = aa;
	}

	private static final void fm(int func, int i, int[] key, int[] a, int[] x) {
		int[] e = new int[48], ikey = new int[56], y = new int[48];
		int j, k, r;
		for (j = 0; j < 32; j++)
			e[j] = a[j];
		transpose(e, Etr, 48);
		for (j = 1; func == 1 && j <= Rots[i]; j++)
			rotateleft(key);
		for (j = 1; func == -1 && i > 0 && j <= Rots[16 - i]; j++)
			rotateright(key);
		for (j = 0; j < 56; j++)
			ikey[j] = key[j];
		transpose(ikey, KeyTr2, 48);
		for (j = 0; j < 48; j++)
			y[j] = (e[j] != ikey[j]) ? 1 : 0;
		for (k = 0; k < 8; k++) {
			r = 32 * y[6 * k] + 16 * y[6 * k + 5] + 8 * y[6 * k + 1] + 4 * y[6 * k + 2] + 2 * y[6 * k + 3]
					+ y[6 * k + 4];
			x[4 * k] = ((S[k][r] % 16) >= 8) ? 1 : 0;
			x[4 * k + 1] = ((S[k][r] % 8) >= 4) ? 1 : 0;
			x[4 * k + 2] = ((S[k][r] % 4) >= 2) ? 1 : 0;
			x[4 * k + 3] = (S[k][r] % 2);
		}
		transpose(x, Ptr, 32);
	}

	private static final void xdes(int[] plaintext, int[] key, int[] ciphertext, int func) {
		int i, j;
		int[] a = new int[64], x = new int[32];
		for (i = 0; i < 64; i++)
			a[i] = plaintext[i];
		transpose(a, InitialTr, 64);
		if (func == -1)
			xchange(a);
		transpose(key, KeyTr1, 56);
		for (i = 0; i < 16; i++) {
			if (func == 1)
				xchange(a);
			fm(func, i, key, a, x);
			for (j = 0; j < 32; j++)
				a[j + 32] = (a[j + 32] != x[j]) ? 1 : 0;
			if (func == -1)
				xchange(a);
		}
		if (func == 1)
			xchange(a);
		transpose(a, FinalTr, 64);
		for (i = 0; i < 64; i++)
			ciphertext[i] = a[i];
	}

	private static final void des(byte[] dkey, byte[] tt, byte[] cipher, char f) {
		int[] aaa = new int[64], bbb = new int[64], ccc = new int[64];
		int flag = 1;
		SVC_HEX_2_BIT(dkey, aaa, 8);
		SVC_HEX_2_BIT(tt, bbb, 8);
		if ((f == 'd') || (f == 'D'))
			flag = -1;
		xdes(bbb, aaa, ccc, flag);
		SVC_BIT_2_HEX(ccc, cipher, 8);
	}

	private static byte toByte(char c) {
		byte b = (byte) "0123456789ABCDEF".indexOf(c);
		return b;
	}

	/**
	 * 把16进制字符串转换成字节数组
	 * 
	 * @param hex
	 * @return
	 */
	public static byte[] hexStringToByte(String hex) {
		int len = (hex.length() / 2);
		byte[] result = new byte[len];
		char[] achar = hex.toCharArray();
		for (int i = 0; i < len; i++) {
			int pos = i * 2;
			result[i] = (byte) (toByte(achar[pos]) << 4 | toByte(achar[pos + 1]));
		}
		return result;
	}

	/**
	 * 将字符串格式化为8的倍数
	 * 
	 * @param data
	 * @return
	 */
	private static byte[] ByteDataFormat(byte[] data) {
		int len = data.length;
		int padlen = len % 8 == 0 ? 0 : 8 - (len % 8);
		int newlen = len + padlen;
		byte[] newdata = new byte[newlen];
		System.arraycopy(data, 0, newdata, 0, len);
		for (int i = len; i < newlen; i++)
			newdata[i] = (byte) 0;
		return newdata;
	}

	/**
	 * 把字节数组转换成16进制字符串
	 * 
	 * @param byteArray
	 * @return String
	 */
	public static final String bytesToHexString(byte[] byteArray) {
		StringBuffer sb = new StringBuffer(byteArray.length);
		String sTemp;
		for (int i = 0; i < byteArray.length; i++) {
			sTemp = Integer.toHexString(0xFF & byteArray[i]);
			if (sTemp.length() < 2)
				sb.append(0);
			sb.append(sTemp.toUpperCase());
		}
		return sb.toString();
	}

	/**
	 * 加密
	 * 
	 * @param key
	 * @param source
	 * @return byte[]
	 * @throws Throwable
	 */
	public static byte[] encrypt(byte[] key, byte[] source) throws Throwable {
		byte[] keyByte = ByteDataFormat(key);
		byte[] sourceByte = ByteDataFormat(source);
		byte[] destByte = new byte[sourceByte.length];
		byte[] sourceByteN = new byte[8];
		byte[] destByteN = new byte[8];
		for (int index = 0; index < sourceByte.length; index += 8) {
			System.arraycopy(sourceByte, index, sourceByteN, 0, 8);
			des(keyByte, sourceByteN, destByteN, 'E');
			System.arraycopy(destByteN, 0, destByte, index, 8);
		}
		return destByte;
	}

	/**
	 * 加密
	 * 
	 * @param key
	 * @param source
	 * @return String
	 * @throws Throwable
	 */
	public static String encrypt(String key, String source) throws Throwable {
		byte[] keyByte = ByteDataFormat(hexStringToByte(key));
		byte[] sourceByte = ByteDataFormat(hexStringToByte(source));
		return bytesToHexString(encrypt(keyByte, sourceByte));
	}

	/**
	 * 加密
	 * 
	 * @param key
	 * @param source
	 * @return byte[]
	 * @throws Throwable
	 */
	public static byte[] decrypt(byte[] key, byte[] source) throws Throwable {
		byte[] keyByte = ByteDataFormat(key);
		byte[] sourceByte = ByteDataFormat(source);
		byte[] destByte = new byte[sourceByte.length];
		byte[] sn_text = new byte[8];
		byte[] dn_text = new byte[8];
		for (int index = 0; index < sourceByte.length; index += 8) {
			System.arraycopy(sourceByte, index, sn_text, 0, 8);
			des(keyByte, sn_text, dn_text, 'D');
			System.arraycopy(dn_text, 0, destByte, index, 8);
		}
		return destByte;
	}

	/**
	 * 解密
	 * 
	 * @param key
	 * @param source
	 * @return String
	 * @throws Throwable
	 */
	public static String decrypt(String key, String source) throws Throwable {
		byte[] keyByte = hexStringToByte(key);
		byte[] sourceByte = hexStringToByte(source);
		return bytesToHexString(decrypt(keyByte, sourceByte));
	}

	/*
	 * 16进制数字字符集
	 */
	private static final String HEX_STRING = "0123456789ABCDEF";

	/*
	 * 将字符串编码成16进制数字,适用于所有字符（包括中文）
	 */
	public static String encodeHex(String str, String charset) throws UnsupportedEncodingException {
		// 根据默认编码获取字节数组
		byte[] bytes = str.getBytes(charset);
		StringBuilder sb = new StringBuilder(bytes.length * 2);
		// 将字节数组中每个字节拆解成2位16进制整数
		for (int i = 0; i < bytes.length; i++) {
			sb.append(HEX_STRING.charAt((bytes[i] & 0xf0) >> 4));
			sb.append(HEX_STRING.charAt((bytes[i] & 0x0f) >> 0));
		}
		return sb.toString();
	}

	/*
	 * 将16进制数字解码成字符串,适用于所有字符（包括中文）
	 */
	public static String decodeHex(String bytes, String charset) throws UnsupportedEncodingException {
		ByteArrayOutputStream baos = new ByteArrayOutputStream(bytes.length() / 2);
		// 将每2位16进制整数组装成一个字节
		for (int i = 0; i < bytes.length(); i += 2)
			baos.write((HEX_STRING.indexOf(bytes.charAt(i)) << 4 | HEX_STRING.indexOf(bytes.charAt(i + 1))));
		return new String(baos.toByteArray(), charset);
	}

	/**
	 * 加密文件 文件开始16个字节为文件长度
	 * 
	 * @param sourceFile
	 *            源文件
	 * @param destFile
	 *            目标文件
	 * @param key
	 *            16个字节的16进制密钥
	 * @throws Throwable
	 *             解密的异常信息
	 */
	public static void encryptFile(String sourceFile, String destFile, String key) throws Throwable {
		byte[] keyByte = ByteDataFormat(hexStringToByte(key));
		InputStream is = new FileInputStream(sourceFile);
		OutputStream os = new FileOutputStream(destFile);
		// 获取文件长度
		String fileLength = String.format("%016d", is.available());
		os.write(fileLength.getBytes());
		byte[] buffer = new byte[1024];
		byte[] encryptByte = new byte[1024];
		while (is.read(buffer) > 0) {
			encryptByte = DesUtil.encrypt(keyByte, buffer);
			os.write(encryptByte, 0, 1024);
		}
		is.close();
		os.close();
	}

	/**
	 * 解密文件 文件开始16个字节为文件长度
	 * 
	 * @param sourceFile
	 *            源文件
	 * @param destFile
	 *            目标文件
	 * @param key
	 *            16个字节的16进制密钥
	 * @throws Throwable
	 *             解密的异常信息
	 */
	public static void decryptFile(String sourceFile, String destFile, String key) throws Throwable {
		byte[] keyByte = ByteDataFormat(hexStringToByte(key));
		InputStream is = new FileInputStream(sourceFile);
		OutputStream os = new FileOutputStream(destFile);
		byte[] buffer = new byte[1024];
		byte[] decryptByte = new byte[1024];
		// 获取文件长度
		byte[] fileLengthByte = new byte[16];
		is.read(fileLengthByte);
		int fileLength = Integer.parseInt(new String(fileLengthByte));
		// 读指定长度
		int readLength = 0;
		int restLength = fileLength;
		while ((readLength = is.read(buffer)) > 0) {
			decryptByte = DesUtil.decrypt(keyByte, buffer);
			if (restLength > readLength) {
				os.write(decryptByte, 0, readLength);
				restLength = restLength - readLength;
			} else {
				os.write(decryptByte, 0, restLength);
			}
		}
		is.close();
		os.close();
	}

	/**
	 * @param args
	 * @throws Throwable
	 */
	public static void main(String[] args) throws Throwable {
		// 16进制字符串
		// String strkey = "1234567811212121";
		String strkey = "1234567890123456";
		// 中英文本字符串
		String source = "中文23中11asd";
		String cipher = DesUtil.encrypt(strkey, encodeHex(source, "GBK"));
		String result = DesUtil.decodeHex(DesUtil.decrypt(strkey, cipher), "GBK");
		System.out.println("source=" + source);
		System.out.println("cipher=" + cipher);
		System.out.println("result=" + result);
		int sourcelen = source.length();
		result = result.substring(0, sourcelen);
		System.out.println(result);

		// DesUtil.encryptFile("G:/src.txt", "G:/encrypt.txt", strkey);
		// DesUtil.decryptFile("G:/encrypt.txt", "G:/decrypt.txt", strkey);
	}
}
