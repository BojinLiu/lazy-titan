package com.jd.common.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.jd.common.context.PagedList;
import com.jd.common.context.PagesBar;

/**
 * @author bjquweixin
 */
public class ViewUtil {
	
	public Entity getEntity() {
		return new Entity();
	}

	static class Entity {
		Entity() {
		}

		String key;
		String value;

		public String getKey() {
			return key;
		}

		public void setKey(String key) {
			this.key = key;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}
	}

	// 页面格式化金额工具
	public static String fromatDecimal(String value) {
		if (StringUtils.isEmpty(value)) {
			return "";
		} else if (value.equals("-")) {
			return value;
		}
		return Arith.thousandCharacterformat(new BigDecimal(value), 2);
	}

	// 页面格式化金额工具
	public static String formatDecimal(String value) {
		if (StringUtils.isEmpty(value)) {
			return "";
		} else if (value.equals("-")) {
			return value;
		}

		return Arith.thousandCharacterformat(new BigDecimal(value), 2);
	}

	public static String formatDecimalStr(String value) {
		if (StringUtils.isEmpty(value)) {
			return "";
		} else if (value.equals("-")) {
			return value;
		}

		return arithFormatDecimal(new BigDecimal(value), 2);
	}

	public static String formatDecimal(BigDecimal value) {
		return Arith.thousandCharacterformat(value, 2); // arithFormatDecimal(value,
														// 2);
	}

	public static String formatDecimalStr(BigDecimal value) {
		return arithFormatDecimal(value, 2); // arithFormatDecimal(value, 2);
	}

	public static String arithFormatDecimal(BigDecimal decimal, int scale) {
		StringBuffer count = new StringBuffer();
		count.append("###0.");
		for (int i = 0; i < scale; i++) {
			count.append("0");
		}
		DecimalFormat format = new DecimalFormat(count.toString());
		return format.format(decimal);
	}

	// 页面格式化金额工具
	public static String fromatDecimalByZero(String value) {
		if (StringUtils.isEmpty(value)) {
			return "0.00";
		} else if (value.equals("-")) {
			return value;
		}
		return Arith.thousandCharacterformat(new BigDecimal(value), 2);
	}

	// 页面格式化金额工具
	public static String fromatDecimal(BigDecimal value) {
		if (null == value) {
			return "";
		}
		return Arith.thousandCharacterformat(value, 2);
	}

	// 页面格式化金额工具
	public static String fromatDecimal(Double value) {
		if (null == value) {
			return "";
		}
		return Arith.thousandCharacterformat(value, 2);
	}

	// 页面格式化时间
	public static String fromatDateToStringYYMMDD(Date date) {
		if (null == date) {
			return "";
		}
		return JdDateUtil.formatDate(date, JdDateUtil.yyyyMMddmmhhss);
	}

	// 页面格式化时间
	public static String fromatDate(Date date, String pattern) {
		if (null == date) {
			return "";
		}
		return JdDateUtil.formatDate(date, StringUtils.isNotBlank(pattern) ? pattern : JdDateUtil.yyyyMMddmmhhss);
	}

	// 页面格式化时间
	public static String formatDate(Date date, String pattern) {
		if (null == date) {
			return "";
		}
		return JdDateUtil.formatDate(date, StringUtils.isNotBlank(pattern) ? pattern : JdDateUtil.yyyyMMddmmhhss);
	}

	// 页面格式化时间
	public static String formatDate2HHmmss(Date date) {
		if (null == date) {
			return "";
		}
		SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
		return sdf.format(date);
	}

	// 页面格式化时间
	public static String fromatDateStringCSTToStringYYMMDD(String dateString) throws ParseException {
		if (StringUtils.isEmpty(dateString)) {
			return "";
		}
		SimpleDateFormat sdf = new SimpleDateFormat("EEE MMM dd HH:mm:ss 'CST' yyyy", Locale.US);
		Date ori = sdf.parse(dateString);
		return JdDateUtil.formatDate(ori, JdDateUtil.yyyyMMddmmhhss);
	}

	// 根据枚举类取得页面option控件
	public static String getOptionDOM(String enumName)
			throws IllegalArgumentException, IllegalAccessException, InvocationTargetException {
		String wholeName = "com.jd.fms.payplatform.common." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		StringBuffer resString = new StringBuffer();
		HashMap<String, String> payplatform_cn_Map = PropertiesUtil.getPayplatform_cn_Map();
		for (Entity e : res) {
			resString.append("<option value=\"");
			resString.append(e.getValue());
			resString.append("\">");
			// resString.append(e.getKey());
			resString.append(payplatform_cn_Map.get(enumName + "." + e.getKey()));
			resString.append("</option>");
		}
		return resString.toString();
	}

	public static Map<String, String> getMapByEnum(String enumName) {
		Map<String, String> map = new LinkedHashMap<String, String>();
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		for (Entity e : res) {
			map.put(e.getKey().toString(), PropertiesUtil.getPropertie(enumName + "." + e.getKey()));
		}

		return map;
	}

	public static Map<String, String> getMapByEnumPrefix(String enumName, String prefix) {
		Map<String, String> map = new LinkedHashMap<String, String>();
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		for (Entity e : res) {
			if (e.getKey().indexOf(prefix) == 0)
				map.put(e.getKey().toString(), PropertiesUtil.getPropertie(enumName + "." + e.getKey()));
		}

		return map;
	}

	// 根据枚举类取得页面option控件
	public static String getOptionDOMByValue(String enumName, String value) {
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		StringBuffer resString = new StringBuffer();

		for (Entity e : res) {
			resString.append("<option value=\"");
			resString.append(e.getValue());
			String temp = (String) e.getValue();
			if (temp.equals(value)) {
				resString.append("\" selected = \"" + "selected\"");
			}
			resString.append("\">");
			// resString.append(e.getKey());
			resString.append((String) PropertiesUtil.getPropertie(enumName + "." + e.getKey()));
			resString.append("</option>");
		}
		return resString.toString();
	}

	// 获得订单类型取得页面option列表
	public static String getOrderOptionByValue(String enumName, String value) {
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		StringBuffer resString = new StringBuffer();

		for (Entity e : res) {
			resString.append("<option value=\"");
			resString.append(e.getValue());
			String temp = (String) e.getValue();
			if (temp.equals(value)) {
				resString.append("\" selected = \"" + "selected\"");
			}
			resString.append("\">");
			// resString.append(e.getKey());
			resString.append((String) PropertiesUtil.getPropertie(enumName + "." + e.getKey()));
			resString.append("</option>");
		}
		return resString.toString();
	}

	// 根据枚举类取得页面option控件
	public static String getOptionDOMByValueInPackageCommon(String enumName, String value) {
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		StringBuffer resString = new StringBuffer();

		for (Entity e : res) {
			resString.append("<option value=\"");
			resString.append(e.getValue());
			String temp = (String) e.getValue();
			if (temp.equals(value)) {
				resString.append("\" selected = \"" + "selected\"");
			}
			resString.append("\">");
			// resString.append(e.getKey());
			resString.append((String) PropertiesUtil.getPropertie(enumName + "." + e.getKey()));
			resString.append("</option>");
		}
		return resString.toString();
	}

	// 页面根据变量数值取得对应的文字表达
	public static String getEnumKey(String enumName, String value) {
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String resString = null;
		for (Entity e : res) {
			if (e.getValue().toString().equals(value)) {
				resString = (String) PropertiesUtil.getPropertie(enumName + "." + e.getKey());
				break;
			}
		}
		return resString;
	}

	public static String getEnumKeyByValue(String enumName, Byte value) {
		return getEnumKeyByValue(enumName, Short.valueOf(value));
	}

	public static String getEnumKeyByValue(String enumName, Short value) {
		if (null == value) {
			return "";
		}
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String resString = null;
		for (Entity e : res) {
			if (e.getValue().equals(value.toString())) {
				resString = (String) PropertiesUtil.getPropertie(enumName + "." + e.getKey());
				break;
			}
		}
		return resString;
	}

	public static String getDictKeyByValue(String enumName, String value) {

		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String resString = null;
		for (Entity e : res) {
			if (e.getValue().toString().equals(value)) {
				resString = (String) PropertiesUtil.getPropertie(enumName + "." + e.getKey());
				break;
			}
		}
		return resString;
	}

	// 页面根据变量类型取得对应的文字表达
	public static String getDictKey(String enumName, String values) {
		if (StringUtils.isBlank(values)) {
			return "";
		}
		String[] value = values.split(",");
		if (value.length < 2) {
			return "";
		}
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String resString = null;
		for (Entity e : res) {
			if (e.getValue().toString().equals(value[1])) {
				resString = (String) PropertiesUtil.getPropertie(enumName + "." + e.getKey());
				break;
			}
		}
		return resString;
	}

	// 页面根据变量数值取得对应的文字表达
	public static String getDictKey2(String enumName, String value) {
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String resString = null;
		for (Entity e : res) {
			if (e.getValue().toString().equals(value)) {
				resString = (String) PropertiesUtil.getPropertie(enumName + "." + e.getKey());
				break;
			}
		}
		return resString;
	}

	// 页面根据枚举取得文字表达
	public static String getDictKey2(Enum<?> type) {

		String simpleName = type.getClass().getSimpleName();
		return (String) PropertiesUtil.getPropertie(simpleName + "." + type.name());
	}

	public static boolean assertDictKey(String enumName, String key, String values) {
		String[] value = values.split(",");
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;

		@SuppressWarnings("rawtypes")
		Enum[] entity = null;
		try {
			entity = (Enum[]) (Class.forName(wholeName)).getEnumConstants();
		} catch (ClassNotFoundException e1) {
			e1.printStackTrace();
		}
		for (@SuppressWarnings("rawtypes")
		Enum e : entity) {
			String content = e.toString();
			String[] c = content.split(",");
			if (c[0].equals(key)) {
				if (c[1].equals(value[0]) || c[1].equals(value[1])) {
					return true;
				} else {
					return false;
				}
			}
		}
		return false;
	}

	public static List<Entity> getListFromEnum(@SuppressWarnings("rawtypes") Enum[] entity) {

		List<Entity> res = new ArrayList<Entity>();
		for (Enum<?> e : entity) {
			String content = e.toString();
			String[] c = content.split(",");
			if (c.length > 0) {
				Entity et = new ViewUtil().getEntity();
				et.setKey(c[0]);
				et.setValue(c[1]);
				res.add(et);
			}
		}
		return res;
	}

	public static List<Entity> getListFromEnum(Class<?> ec) {
		try {
			@SuppressWarnings("rawtypes")
			Enum[] entity = (Enum[]) ec.getEnumConstants();
			List<Entity> res = new ArrayList<Entity>();
			Method method = null;
			for (Enum<?> e : entity) {
				String content = e.toString();

				method = e.getClass().getMethod("value", new Class[0]);

				String[] c = content.split(":");
				if (c.length > 0) {
					Entity et = new ViewUtil().getEntity();
					et.setKey(c[0]);

					et.setValue(String.valueOf(method.invoke(e, null)));
					res.add(et);
				}
			}
			return res;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static <T> PagesBar<T> createPagesBar(PagedList<T> pageList, int width) {
		if (pageList == null) {
			return null;
		}
		return new PagesBar<T>(pageList, width);
	}

	// 页面根据银行的id取银行名称

	public static String getCurrencyType(String payid, String tableName) {
		return "人民币";
	}

	public String getOrderStatusName(String orderstatus) {
		if (StringUtils.isBlank(orderstatus))
			return "未知";
		else
			return PropertiesUtil.getPropertie(orderstatus);
	}

	// 根据枚举类取得页面option控件,startStr是枚举名字开头字母
	public static String getOptionDOMByValue(String enumName, String value, String startStr) {
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		StringBuffer resString = new StringBuffer();

		for (Entity e : res) {
			if (!e.getKey().startsWith(startStr)) {
				continue;
			}

			resString.append("<option value=\"");
			resString.append(e.getValue());
			String temp = (String) e.getValue();
			if (temp.equals(value)) {
				resString.append("\" selected = \"" + "selected\"");
			}
			resString.append("\">");
			// resString.append(e.getKey());
			resString.append((String) PropertiesUtil.getPropertie(enumName + "." + e.getKey()));
			resString.append("</option>");
		}
		return resString.toString();
	}

	public static boolean isEqualsByEnumKeyValue(String enumName, String key, String value) {
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		for (Entity e : res) {
			if (e.getKey().equals(key) && e.getValue().equals(value)) {
				return true;
			}
		}
		return false;
	}

	public static String getEnumValueByKeyName(String enumName, String keyName) {
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		for (Entity e : res) {
			if (e.getKey().equals(keyName)) {
				return e.getValue();
			}
		}
		return null;
	}

	// 页面根据变量数值取得对应的文字表达,加入key的开始字符串
	public static String getEnumKey(String enumName, String value, String keyNameStartStr) {
		String wholeName = "com.jd.project.custenum.domainTypeEnum." + enumName;
		List<Entity> res = new ArrayList<Entity>();
		try {
			res = ViewUtil.getListFromEnum((Class.forName(wholeName)));
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		String resString = null;
		for (Entity e : res) {
			if (e.getValue().toString().equals(value) && e.getKey().startsWith(keyNameStartStr)) {
				resString = (String) PropertiesUtil.getPropertie(enumName + "." + e.getKey());
				break;
			}
		}
		return resString;
	}
}
