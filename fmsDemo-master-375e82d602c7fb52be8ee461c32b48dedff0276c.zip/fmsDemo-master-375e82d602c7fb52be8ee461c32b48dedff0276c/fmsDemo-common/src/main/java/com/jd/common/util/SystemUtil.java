package com.jd.common.util;

public class SystemUtil {
	public static boolean isWindows() {
		boolean flag = false;
		if (System.getProperties().getProperty("os.name").toUpperCase().indexOf("WIN") != -1) {
			flag = true;
		}
		return flag;
	}
}