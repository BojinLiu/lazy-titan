package com.jd.common.util;

import java.util.HashMap;
import java.util.Map;

import javax.script.ScriptException;

import com.jd.common.domain.CustJsFun;

/**
 * author by http://www.bt285.cn/content.php?id=1196863
 */
public class CustSqlScriptUtil {

	private static String funcStr = "function trans(jo,rs){for(var i = 0;i<jo.length;i++){rs.put(jo[i].value+'',jo[i].text+'');}return rs;}";
	private static CustJsFun<Map> fun = null;
	static {
		try {
			fun = ScriptUtil.getFun("trans", funcStr, Map.class);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static Map<String, String> initRs(String jsonStr) throws ScriptException{
		Map<String, String> rs = new HashMap<String, String>();
		ScriptUtil.getResult(jsonStr, rs, fun);
		return rs;
	}
}