/**
 * copyright (c) 360buy.com 
 * package: com.jd.fms.payplatform.common.converter
 * @since 2013-8-12
 * @author zhouwei(zhouweiinfo@360buy.com)
 */
package com.jd.common.springmvc.converter;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.core.convert.converter.Converter;

import com.jd.common.util.StringUtils;

/**
 * class StringToDateConverter
 * 
 * @since 2013-8-12
 * @author zhouwei(zhouweiinfo@360buy.com)
 */
public class StringToDateConverter implements Converter<String, Date> {

	private String dateFormat = "yyyy-MM-dd HH:mm:ss";

	protected Logger log = Logger.getLogger(getClass());

	public StringToDateConverter(String pattern) {
		dateFormat = ((pattern == null || pattern.trim().length() < 1) ? dateFormat : pattern);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.springframework.core.convert.converter.Converter#convert(java.lang
	 * .Object)
	 */
	@Override
	public Date convert(String source) {
		try {
			if (StringUtils.isBlank(source))
				return null;
			if (source.length() >= 8 && source.length() <= 10 && source.indexOf("-") > -1) {
				return new SimpleDateFormat("yyyy-MM-dd").parse(source);
			} else if (source.length() >= 8 && source.length() <= 10 && source.indexOf("/") > -1) {
				return new SimpleDateFormat("yyyy/MM/dd").parse(source);
			} else if (source.length() >= 14 && source.length() <= 16 && source.indexOf("-") > -1) {
				return new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(source);
			} else if (source.length() >= 14 && source.length() <= 16 && source.indexOf("/") > -1) {
				return new SimpleDateFormat("yyyy/MM/dd HH:mm").parse(source);
			} else if (source.length() >= 17 && source.length() <= 19 && source.indexOf("-") > -1) {
				return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(source);
			} else if (source.length() >= 17 && source.length() <= 19 && source.indexOf("/") > -1) {
				return new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").parse(source);
			} else {
				log.error(getClass().getSimpleName() + " convert String to date failed,maybe the pattern is not supported:" + source);
				return null;
			}
		} catch (Exception e) {
			log.error(getClass().getSimpleName() + " convert String to date failed for '" + source + "',reason:", e);
			return null;
		}

	}
}
