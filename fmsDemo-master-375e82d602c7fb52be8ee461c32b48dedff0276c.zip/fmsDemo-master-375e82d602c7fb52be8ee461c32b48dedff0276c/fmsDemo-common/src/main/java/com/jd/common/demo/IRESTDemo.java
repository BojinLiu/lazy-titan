package com.jd.common.demo;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import com.jd.common.demo.webbean.WebDemoItem;

@Path(value = "/sample")
public interface IRESTDemo {
	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	public String doGet();

	@GET
	@Produces({ MediaType.APPLICATION_JSON })
	@Path("/request/{param}")
	public String doRequest(@PathParam("param") String param, @Context HttpServletRequest servletRequest, @Context HttpServletResponse servletResponse);
	
	@GET
	@Path("/bean/{id}")
	@Produces({ "application/json;charset=UTF-8" })
	public WebDemoItem getBean(@PathParam("id") int id, @QueryParam("para") String para);

	@POST
	@Path("/postData")
	public WebDemoItem postData(WebDemoItem user) throws IOException;

	@PUT
	@Path("/putData/{id}")
	@Consumes("application/json;charset=UTF-8")
	public WebDemoItem putData(@PathParam("id") int id, WebDemoItem user);

	@DELETE
	@Path("/removeData/{id}")
	public void deleteData(@PathParam("id") int id);

}
