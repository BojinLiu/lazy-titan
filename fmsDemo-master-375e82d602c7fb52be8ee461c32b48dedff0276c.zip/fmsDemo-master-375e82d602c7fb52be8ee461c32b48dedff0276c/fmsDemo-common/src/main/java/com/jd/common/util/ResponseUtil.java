package com.jd.common.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Response
 */
public class ResponseUtil {
	private static Map<String, String> contentTypeMap = new HashMap<String, String>();
	static {
		contentTypeMap.put("oda", "application/oda");
		contentTypeMap.put("xls", "application/vnd.ms-excel");
		contentTypeMap.put("snd", "audio/basic");
		contentTypeMap.put("tar", "application/x-tar");
		contentTypeMap.put("htm", "text/html");
		contentTypeMap.put("ras", "image/x-cmu-raster");
		contentTypeMap.put("midi", "audio/midi");
		contentTypeMap.put("smi", "application/smil");
		contentTypeMap.put("mpeg", "video/mpeg");
		contentTypeMap.put("xml", "text/xml");
		contentTypeMap.put("ram", "audio/x-pn-realaudio");
		contentTypeMap.put("gif", "image/gif");
		contentTypeMap.put("texi", "application/x-texinfo");
		contentTypeMap.put("t", "application/x-troff");
		contentTypeMap.put("exe", "application/octet-stream");
		contentTypeMap.put("mid", "audio/midi");
		contentTypeMap.put("ief", "image/ief");
		contentTypeMap.put("dvi", "application/x-dvi");
		contentTypeMap.put("txt", "text/plain");
		contentTypeMap.put("eps", "application/postscript");
		contentTypeMap.put("dir", "application/x-director");
		contentTypeMap.put("jpg", "image/jpeg");
		contentTypeMap.put("sh", "application/x-sh");
		contentTypeMap.put("wbxml", "application/vnd.wap.wbxml");
		contentTypeMap.put("etx", "text/x-setext");
		contentTypeMap.put("pdf", "application/pdf");
		contentTypeMap.put("lha", "application/octet-stream");
		contentTypeMap.put("spl", "application/x-futuresplash");
		contentTypeMap.put("zip", "application/zip");
		contentTypeMap.put("djv", "image/vnd.djvu");
		contentTypeMap.put("bmp", "image/bmp");
		contentTypeMap.put("css", "text/css");
		contentTypeMap.put("jpeg", "image/jpeg");
		contentTypeMap.put("iges", "model/iges");
		contentTypeMap.put("csh", "application/x-csh");
		contentTypeMap.put("rtx", "text/richtext");
		contentTypeMap.put("skp", "application/x-koan");
		contentTypeMap.put("latex", "application/x-latex");
		contentTypeMap.put("tcl", "application/x-tcl");
		contentTypeMap.put("dms", "application/octet-stream");
		contentTypeMap.put("mxu", "video/vnd.mpegurl");
		contentTypeMap.put("au", "audio/basic");
		contentTypeMap.put("bcpio", "application/x-bcpio");
		contentTypeMap.put("rtf", "text/rtf");
		contentTypeMap.put("rpm", "audio/x-pn-realaudio-plugin");
		contentTypeMap.put("m3u", "audio/x-mpegurl");
		contentTypeMap.put("texinfo", "application/x-texinfo");
		contentTypeMap.put("xwd", "image/x-xwindowdump");
		contentTypeMap.put("sgml", "text/sgml");
		contentTypeMap.put("src", "application/x-wais-source");
		contentTypeMap.put("skm", "application/x-koan");
		contentTypeMap.put("wav", "audio/x-wav");
		contentTypeMap.put("sv4crc", "application/x-sv4crc");
		contentTypeMap.put("wmls", "text/vnd.wap.wmlscript");
		contentTypeMap.put("swf", "application/x-shockwave-flash");
		contentTypeMap.put("ppt", "application/vnd.ms-powerpoint");
		contentTypeMap.put("dcr", "application/x-director");
		contentTypeMap.put("qt", "video/quicktime");
		contentTypeMap.put("roff", "application/x-troff");
		contentTypeMap.put("shar", "application/x-shar");
		contentTypeMap.put("tsv", "text/tab-separated-values");
		contentTypeMap.put("png", "image/png");
		contentTypeMap.put("mpga", "audio/mpeg");
		contentTypeMap.put("cpt", "application/mac-compactpro");
		contentTypeMap.put("pbm", "image/x-portable-bitmap");
		contentTypeMap.put("aiff", "audio/x-aiff");
		contentTypeMap.put("msh", "model/mesh");
		contentTypeMap.put("nc", "application/x-netcdf");
		contentTypeMap.put("rgb", "image/x-rgb");
		contentTypeMap.put("class", "application/octet-stream");
		contentTypeMap.put("vrml", "model/vrml");
		contentTypeMap.put("xyz", "chemical/x-xyz");
		contentTypeMap.put("jpe", "image/jpeg");
		contentTypeMap.put("sit", "application/x-stuffit");
		contentTypeMap.put("pgn", "application/x-chess-pgn");
		contentTypeMap.put("aifc", "audio/x-aiff");
		contentTypeMap.put("mpg", "video/mpeg");
		contentTypeMap.put("kar", "audio/midi");
		contentTypeMap.put("rm", "audio/x-pn-realaudio");
		contentTypeMap.put("movie", "video/x-sgi-movie");
		contentTypeMap.put("wbmp", "image/vnd.wap.wbmp");
		contentTypeMap.put("djvu", "image/vnd.djvu");
		contentTypeMap.put("wmlsc", "application/vnd.wap.wmlscriptc");
		contentTypeMap.put("ms", "application/x-troff-ms");
		contentTypeMap.put("asc", "text/plain");
		contentTypeMap.put("ai", "application/postscript");
		contentTypeMap.put("mesh", "model/mesh");
		contentTypeMap.put("xhtml", "application/xhtml+xml");
		contentTypeMap.put("hdf", "application/x-hdf");
		contentTypeMap.put("tex", "application/x-tex");
		contentTypeMap.put("lzh", "application/octet-stream");
		contentTypeMap.put("dll", "application/octet-stream");
		contentTypeMap.put("sv4cpio", "application/x-sv4cpio");
		contentTypeMap.put("vcd", "application/x-cdlink");
		contentTypeMap.put("pgm", "image/x-portable-graymap");
		contentTypeMap.put("js", "application/x-javascript");
		contentTypeMap.put("ez", "application/andrew-inset");
		contentTypeMap.put("ppm", "image/x-portable-pixmap");
		contentTypeMap.put("silo", "model/mesh");
		contentTypeMap.put("mp2", "audio/mpeg");
		contentTypeMap.put("hqx", "application/mac-binhex40");
		contentTypeMap.put("dxr", "application/x-director");
		contentTypeMap.put("ps", "application/postscript");
		contentTypeMap.put("smil", "application/smil");
		contentTypeMap.put("wrl", "model/vrml");
		contentTypeMap.put("mp3", "audio/mpeg");
		contentTypeMap.put("tr", "application/x-troff");
		contentTypeMap.put("ra", "audio/x-realaudio");
		contentTypeMap.put("html", "text/html");
		contentTypeMap.put("cdf", "application/x-netcdf");
		contentTypeMap.put("aif", "audio/x-aiff");
		contentTypeMap.put("doc", "application/msword");
		contentTypeMap.put("me", "application/x-troff-me");
		contentTypeMap.put("skd", "application/x-koan");
		contentTypeMap.put("pnm", "image/x-portable-anymap");
		contentTypeMap.put("sgm", "text/sgml");
		contentTypeMap.put("ustar", "application/x-ustar");
		contentTypeMap.put("xpm", "image/x-xpixmap");
		contentTypeMap.put("xht", "application/xhtml+xml");
		contentTypeMap.put("avi", "video/x-msvideo");
		contentTypeMap.put("ice", "x-conference/x-cooltalk");
		contentTypeMap.put("cpio", "application/x-cpio");
		contentTypeMap.put("so", "application/octet-stream");
		contentTypeMap.put("mov", "video/quicktime");
		contentTypeMap.put("skt", "application/x-koan");
		contentTypeMap.put("tiff", "image/tiff");
		contentTypeMap.put("form", "application/x-www-form-urlencoded");
		contentTypeMap.put("xbm", "image/x-xbitmap");
		contentTypeMap.put("mif", "application/vnd.mif");
		contentTypeMap.put("tif", "image/tiff");
		contentTypeMap.put("igs", "model/iges");
		contentTypeMap.put("pdb", "chemical/x-pdb");
		contentTypeMap.put("wmlc", "application/vnd.wap.wmlc");
		contentTypeMap.put("xsl", "text/xml");
		contentTypeMap.put("man", "application/x-troff-man");
		contentTypeMap.put("gtar", "application/x-gtar");
		contentTypeMap.put("wml", "text/vnd.wap.wml");
		contentTypeMap.put("csv", "application/ms-txt");
		contentTypeMap.put("bin", "application/octet-stream");
		contentTypeMap.put("mpe", "video/mpeg");
		contentTypeMap.put("xlsx", "application/vnd.ms-excel");
		contentTypeMap.put("rar", "application/x-msdownload");
	}

	public static String getContentTypeByName(String fileName) {
		String typeName = "txt";
		int li = fileName.lastIndexOf(".");
		if (li != -1) {
			typeName = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
		}
		String contentType = contentTypeMap.get(typeName);
		if (contentType == null) {
			contentType = contentTypeMap.get("txt");
		}
		return contentType;
	}
}
