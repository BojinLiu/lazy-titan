package com.jd.common.interceptor;

import javax.xml.namespace.QName;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.saaj.SAAJInInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.log4j.Logger;
import org.w3c.dom.Element;

import com.jd.common.ws.AuthHeader;

public class CheckSOAPHeaderIntercepter extends AbstractPhaseInterceptor<SoapMessage> {

	private Logger logger = Logger.getLogger(getClass());

	private AuthHeader authHeader;

	public CheckSOAPHeaderIntercepter() {
		super(Phase.PRE_PROTOCOL);
		getAfter().add(SAAJInInterceptor.class.getName());
	}

	public void handleMessage(SoapMessage message) throws Fault {
		if(authHeader == null){
			throw new IllegalArgumentException("authHeader must set!");
		}
		org.apache.cxf.binding.soap.SoapHeader soapHeader = (org.apache.cxf.binding.soap.SoapHeader) message
				.getHeader(new QName(authHeader.getqName(), authHeader.getKey()));
		if (soapHeader == null) {
			throw new IllegalArgumentException("Token null! ");
		}
		Element ei = (Element) soapHeader.getObject();
		String token = null;
		try {
			org.w3c.dom.Node node = ei.getFirstChild().getFirstChild();
			if (node != null) {
				token = node.getTextContent();
			} else {
				token = "";
			}
		} catch (Exception e) {
			logger.error("token:" + token);
			throw new IllegalArgumentException("Token wrong! ");
		}
		boolean b = checkTokenValue(token);
		if (!b) {
			throw new IllegalArgumentException("Token wrong! ");
		}
	}

	private boolean checkTokenValue(String token) {
		String tmp = authHeader.getTokenValue();
		if (StringUtils.isEmpty(tmp)) {
			return true;
		}
		if (StringUtils.isEmpty(token)) {
			return false;
		}
		return tmp.equals(token);
	}

	public void setAuthHeader(AuthHeader authHeader) {
		this.authHeader = authHeader;
	}

}
