package com.jd.common.springmvc.interceptor;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.jd.common.web.LoginContext;

public class TestLoginContextInterceptor extends HandlerInterceptorAdapter {

	@Override
	public final boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws ServletException, IOException {
		LoginContext.setLoginContext(new LoginContext());
		LoginContext.getLoginContext().setPin("bjadmin");
		return true;
	}

	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) throws Exception {
		LoginContext.remove();
	}
}
