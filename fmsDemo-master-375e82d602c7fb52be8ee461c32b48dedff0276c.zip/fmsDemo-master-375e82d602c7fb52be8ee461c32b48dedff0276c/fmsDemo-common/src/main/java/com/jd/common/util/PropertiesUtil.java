package com.jd.common.util;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

/**
 * @Title: PropertiesUtil.java
 * @Description:Properties文件读取初始化类
 * @author 哲同
 * @date 2011-11-14 上午10:15:21
 * @version V1.0
 */
public class PropertiesUtil
{
	private static ArrayList<String> filelist = new ArrayList<String>();

	private static HashMap<String, String> properties_Map = new HashMap<String, String>();

	private static HashMap<String, String> payplatform_cn_Map = new HashMap<String, String>();

	public static HashMap<String, String> getPayplatform_cn_Map()
	{

		return payplatform_cn_Map;
	}

	static
	{
		// settlementConstant资源文件初始化
		refreshFileList(PropertiesUtil.class.getResource("/").getPath());
		for (String proFileName : filelist)
		{
			initHashMap(properties_Map, proFileName);
		}
		initHashMap(payplatform_cn_Map, "enumConstant_pay.properties");
	}

	private static void initHashMap(HashMap<String, String> oriMap, String propName)
	{
		Properties prop = new Properties();

		try
		{

			InputStream in = PropertiesUtil.class.getClassLoader().getResourceAsStream(propName);

			prop.load(in);
			in.close();
		}
		catch (IOException e)
		{
			e.printStackTrace();
		}
		@SuppressWarnings("rawtypes")
		Set keyValue = prop.keySet();
		for (@SuppressWarnings("rawtypes")
		Iterator it = keyValue.iterator(); it.hasNext();)
		{
			String key = (String) it.next();
			String value = (String) prop.getProperty(key);
			oriMap.put(key, value);
		}

	}

	public static String getPropertie(String key)
	{
		return (String) properties_Map.get(key);
	}

	public static void refreshFileList(String strPath)
	{
		File dir = new File(strPath);
		File[] files = dir.listFiles();
		if (files == null)
			return;
		for (int i = 0; i < files.length; i++)
		{
			if (!files[i].isDirectory())
			{
				String strFileName = files[i].getName();
				if (strFileName.endsWith("pay.properties"))
				{
					filelist.add(strFileName);
				}
			}
		}
	}

	public static void main(String args[])
	{
		System.out.println(PropertiesUtil.getPropertie("PayplatformConstant$SETTLEMENT_ORDERTYPE.ORDER"));
		System.out.println(PropertiesUtil.getPropertie("InputType.Auto"));
	}
}
