package com.jd.common.util;

import org.springframework.beans.factory.InitializingBean;

import com.jd.ump.profiler.proxy.Profiler;

public class UmpUtil implements InitializingBean {

	private String jvmKey;
	private String systemKey;

	public UmpUtil(String jvmKey, String systemKey) {
		super();
		this.jvmKey = jvmKey;
		this.systemKey = systemKey;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		Profiler.registerJVMInfo(jvmKey);
		Profiler.InitHeartBeats(systemKey);
	}

}
