/**
 * copyright (c) 360buy.com 
 * package: com.jd.fms.payplatform.web.controller
 * @since 2013-8-9
 * @author zhouwei(zhouweiinfo@360buy.com)
 */
package com.jd.common.demo;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.jd.common.demo.webbean.WebDemoItem;

/**
 * class DemoController
 * 
 * @since 2013-8-9
 */
public class RESTDemo implements IRESTDemo {

	@Override
	public String doGet() {
		return null;
	}

	@Override
	public String doRequest(String param, HttpServletRequest servletRequest, HttpServletResponse servletResponse) {
		System.out.println(param);
		return null;
	}

	@Override
	public WebDemoItem getBean(int id, String para) {
		WebDemoItem webWebDemoItem = new WebDemoItem();
		webWebDemoItem.setUserName("userName中文"+para);
		webWebDemoItem.setValue("value"+para);
		webWebDemoItem.setEmail("email"+para);
		return webWebDemoItem;
	}

	@Override
	public WebDemoItem postData(WebDemoItem user) throws IOException {
		return user;
	}

	@Override
	public WebDemoItem putData(int id, WebDemoItem user) {
		return null;
	}

	@Override
	public void deleteData(int id) {
	}
}
