package com.jd.common;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.servlet.ModelAndView;

import com.jd.common.springmvc.CustMessageSource;

public class BaseControl {

	protected Logger log = Logger.getLogger(getClass());
	
	@Resource
	protected CustMessageSource messageSource;

	@InitBinder
	public void initBinder(WebDataBinder binder) throws Exception {
	}

	@ExceptionHandler(Exception.class)
	public ModelAndView handleIOException(Exception ex, HttpServletRequest request) {
		log.error(request.getPathInfo(), ex);
		return new ModelAndView("error").addObject("exception", ex);
	}
}
