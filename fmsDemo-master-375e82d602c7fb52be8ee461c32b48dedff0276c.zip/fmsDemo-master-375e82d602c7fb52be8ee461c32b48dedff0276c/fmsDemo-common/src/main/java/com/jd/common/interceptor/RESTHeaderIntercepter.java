package com.jd.common.interceptor;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.springframework.http.HttpRequest;
import org.springframework.http.client.ClientHttpRequestExecution;
import org.springframework.http.client.ClientHttpRequestInterceptor;
import org.springframework.http.client.ClientHttpResponse;

import org.apache.cxf.binding.soap.saaj.SAAJInInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.XMLMessage;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

import com.jd.common.ws.AuthHeader;

public class RESTHeaderIntercepter extends AbstractPhaseInterceptor<XMLMessage> {

	private AuthHeader authHeader;

	public void setAuthHeader(AuthHeader authHeader) {
		this.authHeader = authHeader;
	}
	
	public RESTHeaderIntercepter() {
		super(Phase.PRE_PROTOCOL);
		getAfter().add(SAAJInInterceptor.class.getName());
	}
	
	@SuppressWarnings("rawtypes")
	@Override
	public void handleMessage(XMLMessage message) throws Fault {
		if(authHeader == null){
			throw new IllegalArgumentException("authHeader must set!");
		}
		Map<String,ArrayList> header = (Map<String,ArrayList>)message.get(org.apache.cxf.message.Message.PROTOCOL_HEADERS);
		ArrayList arrayList = new ArrayList();
		arrayList.add(authHeader.getTokenValue());
		header.put(authHeader.getKey().toLowerCase(), arrayList);
	}
	
}
