package com.jd.common.util;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.tools.tar.TarEntry;
import org.apache.tools.tar.TarInputStream;
import org.apache.tools.tar.TarOutputStream;

public class TarUtil {

	public static void main(String[] args) throws Exception {
		TarUtil jtar = new TarUtil();
		// jtar.tar(new
		// File("D:/temp/refund/_refund_bak"),"D:/temp/refund/_refund_bak.tar");
		jtar.unTar(new File("D:/temp/refund/10000400_refund_20111031.tar"), "D:/temp/refund/");
	}

	/**
	 * 归档tar文件
	 * 
	 * @throws IOException
	 */
	public static File tar(File srcFile, String targetFileName) throws IOException {
		File targetTarFile = new File(targetFileName);// 归档后的文件名
		TarOutputStream out = null;
		boolean boo = false;// 是否压缩成功
		try {
			out = new TarOutputStream(new BufferedOutputStream(new FileOutputStream(targetTarFile)));
			tarNext(srcFile, out, "", true);
			boo = true;
			// 归档成功
			return targetTarFile;
		} finally {
			try {
				if (out != null) {
					out.close();
				}
			} catch (IOException ex) {
				throw new RuntimeException("关闭Tar输出流出现异常", ex);
			} finally {
				// 清理操作
				if (!boo && targetTarFile.exists())// 归档不成功,
					targetTarFile.delete();
			}
		}
	}

	/**
	 * 解压tar File
	 * 
	 * @param file
	 *            要解压的tar文件对象
	 * @param outputDir
	 *            要解压到某个指定的目录下
	 * @throws IOException
	 */
	public static File unTar(File file, String outputDir) throws IOException {
		File creatFile = null;
		TarInputStream tarIn = null;
		boolean success = false;
		try {
			if (file.exists() == false) {
				return creatFile;
			}
			tarIn = new TarInputStream(new FileInputStream(file), 1024 * 2);
			createDirectory(outputDir, null);// 创建输出目录
			TarEntry entry = null;
			while ((entry = tarIn.getNextEntry()) != null) {
				if (entry.isDirectory()) {// 是目录
					createDirectory(outputDir, entry.getName());// 创建空目录
				} else {// 是文件
					File tmpFile = new File(outputDir + "/" + entry.getName());
					createDirectory(tmpFile.getParent() + "/", null);// 创建输出目录
					OutputStream out = null;
					try {
						out = new FileOutputStream(tmpFile);
						int length = 0;
						byte[] b = new byte[2048];
						while ((length = tarIn.read(b)) != -1) {
							out.write(b, 0, length);
						}
					} catch (IOException ex) {
						throw ex;
					} finally {
						if (out != null)
							out.close();
					}
				}
			}
			success = true;
			creatFile = new File(outputDir);
		} finally {
			try {
				if (tarIn != null) {
					tarIn.close();
				}
				// if(!success){
				// deleteDirectory(new File(outputDir));
				// }
			} catch (IOException ex) {
				throw new IOException("关闭tarFile出现异常", ex);
			}
		}
		return creatFile;
	}

	/**
	 * 归档tar文件
	 * 
	 * @param file
	 *            归档的文件对象
	 * @param out
	 *            输出tar流
	 * @param dir
	 *            相对父目录名称
	 * @param boo
	 *            是否把空目录归档进去
	 */
	private static void tarNext(File file, TarOutputStream out, String dir, boolean boo) throws IOException {
		if (file.isDirectory()) {// 是目录
			File[] listFile = file.listFiles();// 得出目录下所有的文件对象
			if (listFile.length == 0 && boo) {// 空目录归档
				out.putNextEntry(new TarEntry(dir + file.getName() + "/"));// 将实体放入输出Tar流中
				System.out.println("归档." + dir + file.getName() + "/");
				return;
			} else {
				for (File cfile : listFile) {
					tarNext(cfile, out, dir + file.getName() + "/", boo);// 递归归档
				}
			}
		} else if (file.isFile()) {// 是文件
			System.out.println("归档." + dir + file.getName() + "/");
			byte[] bt = new byte[2048 * 2];
			TarEntry ze = new TarEntry(dir + file.getName());// 构建tar实体
			// 设置压缩前的文件大小
			ze.setSize(file.length());
			// ze.setName(file.getName());//设置实体名称.使用默认名称
			out.putNextEntry(ze);// //将实体放入输出Tar流中
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);
				int i = 0;
				while ((i = fis.read(bt)) != -1) {// 循环读出并写入输出Tar流中
					out.write(bt, 0, i);
				}
			} catch (IOException ex) {
				throw new IOException("写入归档文件出现异常", ex);
			} finally {
				try {
					if (fis != null)
						fis.close();// 关闭输入流
					out.closeEntry();
				} catch (IOException ex) {
					throw new IOException("关闭输入流出现异常");
				}
			}
		}
	}

	/**
	 * 构建目录
	 * 
	 * @param outputDir
	 * @param subDir
	 */
	private static void createDirectory(String outputDir, String subDir) {
		File file = new File(outputDir);
		if (!(subDir == null || subDir.trim().equals(""))) {// 子目录不为空
			file = new File(outputDir + "/" + subDir);
		}
		if (!file.exists()) {
			file.mkdirs();
		}
	}

	/**
	 * 清理文件(目录或文件)
	 * 
	 * @param file
	 */
	private static void deleteDirectory(File file) {
		if (file.isFile()) {
			file.delete();// 清理文件
		} else {
			File list[] = file.listFiles();
			if (list != null) {
				for (File f : list) {
					deleteDirectory(f);
				}
				file.delete();// 清理目录
			}
		}
	}
}
