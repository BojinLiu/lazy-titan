package com.jd.common.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;

import com.jd.common.domain.FtpInfoBean;

public class FtpUtil {
	/**
	 * ftp登陆内部方法
	 * @param ftpInfo
	 * @return
	 * @throws IOException
	 */
	public static FTPClient ftpCommon(FtpInfoBean ftpInfo) throws IOException{
		// 创建FTPClient对象
		FTPClient ftp = new FTPClient();
		// 连接FTP服务器
		ftp.connect(ftpInfo.getUrl(), ftpInfo.getPort());
		// 登录ftp
		ftp.login(ftpInfo.getUserName(), ftpInfo.getPassWord());
		// 看返回的值是不是230，如果是，表示登陆成功
		// 以2开头的返回值就会为真
		if (!FTPReply.isPositiveCompletion(ftp.getReplyCode())) {
			ftp.disconnect();
			throw new IOException("ftp建立连接不成功,检查执行参数");
		}
		// 转到指定上传目录
		ftp.changeWorkingDirectory(ftpInfo.getRemotePath());
		return ftp;
	}
	/**
	 * 上传文件
	 * @param ftpInfo
	 * @param filename
	 * @param input
	 * @return
	 * @throws IOException
	 */
	public static boolean uploadFile(FtpInfoBean ftpInfo, String filename, InputStream input) throws IOException {
		// 初始表示上传失败
		boolean success = false;
		// 创建FTPClient对象
		FTPClient ftp = null;
		try {
			ftp = ftpCommon(ftpInfo);
			// 将上传文件存储到指定目录
			ftp.storeFile(filename, input);
			// 关闭输入流
			input.close();
			// 退出ftp
			ftp.logout();
			// 表示上传成功
			success = true;
		} finally {
			if (ftp!=null && ftp.isConnected()) {
				ftp.disconnect();
			}
		}
		return success;
	}

	/**
	 * 下载文件
	 * @param ftpInfo
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	public static boolean downFile(FtpInfoBean ftpInfo, String fileName) throws IOException {
		// 初始表示下载失败
		boolean success = false;
		// 创建FTPClient对象
		FTPClient ftp = null;
		try {
			ftp = ftpCommon(ftpInfo);
			// 遍历该目录下所有文件，找到指定的文件
			for (FTPFile ff : ftp.listFiles()) {
				if (ff.getName().equals(fileName)) {
					// 根据绝对路径初始化文件
					File localFile = new File(ftpInfo.getLocalPath() + "/" + ff.getName());
					// 输出流
					OutputStream is = new FileOutputStream(localFile);
					// 下载文件
					ftp.retrieveFile(ff.getName(), is);
					is.close();
					// 下载成功
					success = true;
					break;
				}
			}
			// 退出ftp
			ftp.logout();
		} finally {
			if (ftp!=null && ftp.isConnected()) {
				ftp.disconnect();
			}
		}
		return success;
	}

	/**
	 * 从ftp下载文件根据创建日期下载文件
	 * @param ftpInfo
	 * @param DateYMD
	 * @param fileType:文件类型正则表达式
	 * @return
	 * @throws IOException
	 */
	public static List<String> getFileNemesByDay(FtpInfoBean ftpInfo, Date DateYMD, String fileTypeRex) throws IOException {
		List<String> refFiles = new LinkedList<String>();
		// 创建FTPClient对象
		FTPClient ftp = null;
		try {
			ftp = ftpCommon(ftpInfo);
			// 遍历所有文件，找到指定的文件
			for (FTPFile ff : ftp.listFiles()) {
				String name = ff.getName();
				if (name.equals(".") || name.equals("..") || !name.matches(fileTypeRex)) {
					continue;
				}
				if (DateUtils.isSameDay(DateYMD, ff.getTimestamp().getTime())) {
					refFiles.add(name);
				}
			}
			// 退出ftp
			ftp.logout();
		} finally {
			if (ftp!=null && ftp.isConnected()) {
				ftp.disconnect();
			}
		}
		return refFiles;
	}
	/**
	 * 从ftp根据文件名称列表下载文件
	 * @param ftpInfo
	 * @param refFiles
	 * @return
	 * @throws IOException
	 */
	public static List<File> downFileByList(FtpInfoBean ftpInfo, List<String> refFiles) throws IOException {
		List<File> downloadFiles = new LinkedList<File>();
		// 创建FTPClient对象
		FTPClient ftp = null;
		try {
			ftp = ftpCommon(ftpInfo);
			for (String fileName : refFiles) {
				// 重命名成功保证本文件不在正在上传中(运维ftp账号不支持删除权限，此处注掉)
				// boolean rename = ftp.rename(fileName, fileName);
				// if(!rename){
				// Logger.getLogger(getClass()).error("请确认当前ftp账户是否具有查看修改删除权限(重命名),必须权限");
				// continue;
				// }
				File localFile = new File(ftpInfo.getLocalPath() + "/" + fileName);
				OutputStream is = new FileOutputStream(localFile);
				ftp.retrieveFile(fileName, is);
				is.close();
				if (localFile.exists()) {
					downloadFiles.add(localFile);
				}
			}
			ftp.logout();
		} finally {
			if (ftp!=null && ftp.isConnected()) {
				ftp.disconnect();
			}
		}
		return downloadFiles;
	}
}
