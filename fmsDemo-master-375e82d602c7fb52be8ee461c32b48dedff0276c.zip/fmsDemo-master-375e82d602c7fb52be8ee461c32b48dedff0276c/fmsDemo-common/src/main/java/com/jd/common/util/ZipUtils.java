package com.jd.common.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;
import java.util.zip.CheckedOutputStream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * ZIP压缩工具
 * 
 */
public class ZipUtils {

	public static final String TMP = "_tmp";
	private static final String BASE_DIR = "";
	private static final int BUFFER = 1024;

	/**
	 * 压缩
	 * 
	 * @param srcPaths
	 *            源文件名称列表
	 * @param basePath
	 *            目标文件名称
	 * @throws IOException 
	 */
	public static boolean compress(List<String> srcPaths, String basePath) throws IOException {
		List<File> files = new ArrayList<File>();
		for (String srcPath : srcPaths) {
			File srcFile = new File(srcPath);
			files.add(srcFile);
		}

		// _tmp后缀为中间名,打包完毕后更改为原名称
		String destPath = basePath + TMP;
		File tmpFile = new File(destPath);
		if(tmpFile.exists()){
			tmpFile.delete();
		}
		compress(files, tmpFile);
		File zipFile = new File(basePath);
		if(zipFile.exists()){
			zipFile.delete();
		}
		return tmpFile.renameTo(zipFile);
	}

	/**
	 * 压缩
	 * 
	 * @param files
	 *            源文件列表
	 * @param newFile
	 *            目标文件
	 * @throws IOException 
	 */
	public static void compress(List<File> files, File newFile) throws IOException {
		ZipOutputStream zos = null;
		try {
			// 对输出文件做CRC32校验
			CheckedOutputStream cos = new CheckedOutputStream(new FileOutputStream(newFile), new CRC32());
			zos = new ZipOutputStream(cos);
			compressFile(files, zos, BASE_DIR);
		} finally {
			zos.flush();
			zos.close();
		}
	}

	/**
	 * 压缩
	 * 
	 * @param files
	 *            源文件列表
	 * @param zos
	 * @param dir
	 * @throws IOException 
	 * 
	 */
	private static void compressFile(List<File> files, ZipOutputStream zos, String dir) throws IOException {
		for (File file : files) {
			BufferedInputStream bis = null;
			try {
				ZipEntry entry = new ZipEntry(dir + file.getName());
				zos.putNextEntry(entry);
				bis = new BufferedInputStream(new FileInputStream(file));
				
				int count;
				byte data[] = new byte[BUFFER];
				while ((count = bis.read(data, 0, BUFFER)) != -1) {
					zos.write(data, 0, count);
				}
			}finally{
				if(bis != null){
					bis.close();
				}
			}
			file.delete();
		}
		zos.closeEntry();
	}
}
