package com.jd.common.domain;

import javax.script.CompiledScript;

public class CustJsFun<T> {
	private CompiledScript rootFunction;

	public CustJsFun(CompiledScript rootFunction) {
		super();
		this.rootFunction = rootFunction;
	}

	public CompiledScript getRootFunction() {
		return rootFunction;
	}

}
