package com.jd.common.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;


/**
 * 
 * 日期处理类
 * 
 * @author yaolizong
 *
 */
public class DateUtil {

	public static final String FORMATTEXT01 = "yyyy-MM-dd";

	public static final String FORMATTEXT02 = "yyyy-MM-dd HH:mm:ss";

	public static final String FORMATTEXT03 = "yyyyMMddHHmmss";

	public static final String FORMATTEXT04 = "yyyyMMdd";

	public static final String FORMATTEXT05 = "yyyyMMdd_HHmmss";
	
	public static final String FORMATTEXT06 = "yyyy-MM";
	
	public static final String FORMATTEXT07 = "yyyy_MM_dd";
	
	public static final String FORMATTEXT08 = "yyyy";

	public static final String FORMATTEXT09 = "MM";
	
	public static final String FORMATTEXT10 = "dd";
	
	public static final String FORMATTEXT11 = "yyyyMMddHHmmssSSS";
	
	public static final String FORMATTEXT12 = "yyyy-MM-dd HH:mm:ss.SSS";
	
    public static final String FORMATTEXT13 = "yyyy/MM/dd";
	
    public static final String FORMATTEXT14 = "yyyyMM";
    
    public static final String FORMATTEXT15 = "yyyyMMdd";
    
    public static final String FORMATTEXT16 = "MM/dd/yyyy";
    
    public static final String FORMATTEXT17 = "yyyy-MM-dd HH:mm";
    
    public static final String FORMATTEXT18 = "yyyy-M";
    
	/**
	 * 判断某个日期是星期几
	 * 
	 * @param Date
	 * @return int
	 */
	public static final int getWeek(Date date) {

		Calendar c = Calendar.getInstance();

		c.setTime(date);

		int week = c.get(Calendar.DAY_OF_WEEK) - 1;

		if (week == 0) {
			return week = 7;
		} else {
			return week;
		}
	}
	
	
	/**
	 * @param 根据给定的日期格式格式化日期
	 * @return String
	 */
	public static final String formatDate(long time, String formatText) {
		
		SimpleDateFormat format = new SimpleDateFormat(formatText);

		String result = format.format(new Date(time));

		return result;
	}

	/**
	 * 将日期对象转换成指定格式的字符串
	 * 
	 * @param date
	 *            日期对象
	 * @param formatText
	 *            日期格式
	 * @return 日期格式的字符串
	 */
	public static final String formatDate(Date date, String formatText) {

		if (CheckUtil.isNull(date) || CheckUtil.isNull(formatText)) {

			return "";
		}

		SimpleDateFormat formats = new SimpleDateFormat(formatText);

		return formats.format(date);
	}

	public static final String formatDate(String date, String formatText) {

		SimpleDateFormat formats = new SimpleDateFormat(formatText);

		return formats.format(parseDate(date, formatText));
	}
	
	
	/**
	 * 获得当前时间的年部分
	 * 
	 * @return
	 */
	public static final int getCurrentYear() {

		Calendar calendar = Calendar.getInstance();

		return calendar.get(calendar.YEAR);

	}
	
	/**
	 * 获得当前时间的月部分
	 * 
	 * @return
	 */
	public static final int getCurrentMonth() {

		Calendar calendar = Calendar.getInstance();

		return calendar.get(calendar.MONTH) +1;

	}
	
	
	/**
	 * 获得当前时间的日部分
	 * 
	 * @return
	 */
	public static final int getCurrentDay() {

		Calendar calendar = Calendar.getInstance();

		return calendar.get(calendar.DATE);

	}
	

	/**
	 * 获得当前的时间，以给定的格式输出
	 * 
	 * @param formatStr
	 * @return
	 */
	public static final String getCurrentTime(String formatText) {

		SimpleDateFormat format = new SimpleDateFormat(formatText);

		String result = format.format(new Date());

		return result;
	}

	/**
	 * 将日期由字符串格式转换成Date类型
	 * @param strDate
	 * @param format
	 * @return
	 */
	public static final Date parseDate(String strDate, String formatText) {

        SimpleDateFormat df = null;
        Date date = null;
        df = new SimpleDateFormat(formatText);

        try {
            date = df.parse(strDate);
        } catch (ParseException e) {
        	e.printStackTrace();
        }

        return (date);
    }

	/**
	 * 在给定时间基础上加减指定的月份，返回加减之后的日期
	 * @param value
	 * @return
	 */
	public static final Date addMonth(Date date, int value){
		if (CheckUtil.isNull(date)){
			date = new Date();
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.MONTH, value);
		return c.getTime();
	}
	
	/**
	 * 获取给定时间的年
	 * @param date
	 * @return
	 */
	public static final int getDateYear(Date date){
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c.get(Calendar.YEAR);
	}
	
	/**
	 * 获取给定时间的月份
	 * @param date
	 * @return
	 */
	public static final int getDateMonth(Date date){
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		return c.get(Calendar.MONTH)+1;
	}
	
	/**
	 * 在给定时间基础上加减指定的日期，返回加减之后的日期
	 * @param value
	 * @return
	 */
	public static final Date addDay(Date date, int value){
		if (CheckUtil.isNull(date)){
			return null;
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.DAY_OF_MONTH, value);
		return c.getTime();
	}
	
	
	/**
	 * 获取指定日期所在月的第一天日期
	 * @return
	 */
	public static final Date getFirstDayOfMonth(Date date){
		if (CheckUtil.isNull(date)){
			return null;
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.set(Calendar.DATE,1);
		c.set(Calendar.HOUR_OF_DAY, 0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		return c.getTime();
	}
	/**
	 * 获取指定两个年份的区间年份
	 * @param date
	 * @return
	 */
	public static final List<Integer> getIntervalYear(int startYear, int endYear){
		if (CheckUtil.isNull(startYear) || CheckUtil.isNull(endYear)){
			return null;
		}
		if(startYear > endYear){
			return null;
		}
		List<Integer> intervalYear = new ArrayList<Integer>();
		int interval = endYear - startYear;
		for(int i = 0; i <= interval; i++){
			intervalYear.add(startYear+i);
		}
		return intervalYear;
	}
	
	/**
	 * 获取美国东部标准时间
	 * @param formatText
	 * @return
	 */
	public static String getESTTime(String formatText){
		TimeZone tz = TimeZone.getTimeZone("EST");
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat sdf = new SimpleDateFormat(formatText);
		sdf.setTimeZone(tz);
		return sdf.format(calendar.getTime());
	}
	
	
	public static final Date getMonthEnd(String date, String formatText) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(formatText);
		Calendar calendar = Calendar.getInstance();
		try{
			calendar.setTime(dateFormat.parse(date));
		} catch (Exception e){
			e.printStackTrace();
		}
		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMaximum(Calendar.DAY_OF_MONTH));
		return calendar.getTime();
	}
	
	public static final Date getMonthStart(String date, String formatText) {
		SimpleDateFormat dateFormat = new SimpleDateFormat(formatText);
		Calendar calendar = Calendar.getInstance();
		try{
			calendar.setTime(dateFormat.parse(date));
		} catch (Exception e){
			e.printStackTrace();
		}
		calendar.set(Calendar.DAY_OF_MONTH, calendar.getActualMinimum(Calendar.DAY_OF_MONTH));
		return calendar.getTime();
	}
	
	public static void main(String[] args) throws ParseException {
		
		System.out.println(formatDate(getMonthEnd("2016-10", FORMATTEXT06), FORMATTEXT01));
		System.out.println(getDateYear(new Date()));
		System.out.println(getDateMonth(new Date()));
		System.out.println(formatDate(addMonth(new Date(), -9), FORMATTEXT06));
		
		System.out.println(DateUtil.formatDate(DateUtil.addMonth(new Date(), +2), "yyyy-M"));
	}

}
