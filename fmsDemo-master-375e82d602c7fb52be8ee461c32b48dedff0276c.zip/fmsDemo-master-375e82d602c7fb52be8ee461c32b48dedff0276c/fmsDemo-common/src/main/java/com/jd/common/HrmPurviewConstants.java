package com.jd.common;

public class HrmPurviewConstants {
	
	/*
	 * 系统信息管理员
	 */
	public static final String SYS_MANAGER = "FM_POS_SYS_MANAGER";
}
