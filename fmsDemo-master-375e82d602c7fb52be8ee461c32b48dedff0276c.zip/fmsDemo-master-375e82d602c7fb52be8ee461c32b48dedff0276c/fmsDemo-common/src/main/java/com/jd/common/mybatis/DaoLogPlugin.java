package com.jd.common.mybatis;

import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.plugin.Intercepts;
import org.apache.ibatis.plugin.Invocation;
import org.apache.ibatis.plugin.Plugin;
import org.apache.ibatis.plugin.Signature;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.Assert;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

@Intercepts({ @Signature(type = Executor.class, method = "query", args = { MappedStatement.class, Object.class, RowBounds.class, ResultHandler.class }),
		@Signature(type = Executor.class, method = "update", args = { MappedStatement.class, Object.class }) })
public class DaoLogPlugin implements Interceptor {
	
	private static final Logger logger = LoggerFactory.getLogger(DaoLogPlugin.class);

	private final Map<String, String> keyTmp = new ConcurrentHashMap<String, String>();

	private String prefix = null;
	private String keyRex = null;
	private String umpAppName = null;

	@Override
	public Object intercept(Invocation invocation) throws Throwable {
		String key = null;
		Object[] args = invocation.getArgs();
		if (args.length > 0) {
			MappedStatement ms = (MappedStatement) args[0];
			key = ms.getId();
		} else {
			key = "unKnowDao";
		}
		return runLog(key, invocation);
	}

	@Override
	public Object plugin(Object target) {
		return Plugin.wrap(target, this);
	}

	@Override
	public void setProperties(Properties properties) {
		prefix = properties.getProperty("prefix");
		keyRex = properties.getProperty("keyRex");
		umpAppName = properties.getProperty("umpAppName");
		Assert.notNull(prefix, "Property 'prefix' is required");
		Assert.notNull(keyRex, "Property 'keyRex' is required");
		Assert.notNull(umpAppName, "Property 'umpAppName' is required");
	}

	private Object runLog(String key, Invocation invocation) throws Throwable {
		// metrics监控
		CallerInfo info = null;
		try {
			String profilerKey = keyTmp.get(key);
			if (profilerKey == null) {
				// metrics监控不允许有,要统一替换掉
				profilerKey = prefix + key.replaceAll(keyRex, "").replaceAll(",", "_");
				keyTmp.put(key, profilerKey);
			}
			if (logger.isDebugEnabled()) {
				logger.debug("typeKey=" + key + "/profilerKey="+profilerKey);
			}
			info = Profiler.registerInfo(profilerKey, umpAppName, true, true);
		} catch (Throwable e) {
			logger.error("registerInfo[MetricsClient]", e);
		}
		try {
			return invocation.proceed();
		} catch (Throwable e) {
			try {
				if (info != null) {
					Profiler.functionError(info);
				}
			} catch (Throwable e2) {
				logger.error("functionError[MetricsClient]", e2);
			}
			throw e;
		} finally {
			try {
				if (info != null) {
					Profiler.registerInfoEnd(info);
				}
			} catch (Throwable e) {
				logger.error("registerInfoEnd[MetricsClient]", e);
			}
		}
	}
}