package com.jd.common.interceptor;

import org.apache.cxf.binding.soap.SoapHeader;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.interceptor.AbstractSoapInterceptor;
import org.apache.cxf.helpers.DOMUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.phase.Phase;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.jd.common.ws.AuthHeader;

import javax.xml.namespace.QName;
import java.util.List;

/**
 * token��֤ User: sunbingwei Date: 2010-5-22 Time: 18:01:15
 */
public class SOAPHeaderIntercepter extends AbstractSoapInterceptor {
	private AuthHeader authHeader;

	public SOAPHeaderIntercepter() {
		super(Phase.WRITE);
	}

	public void handleMessage(SoapMessage soapMessage) throws Fault {
		List headers = soapMessage.getHeaders();
		headers.add(getHeader());
	}

	private Object getHeader() {
		QName qName = new QName(authHeader.getqName(), authHeader.getKey(), "");
		Document document = DOMUtils.createDocument();
		Element element = document.createElementNS(authHeader.getqName(), authHeader.getKey());
		Element token = document.createElement(authHeader.getToken());
		token.setTextContent(authHeader.getTokenValue());
		element.appendChild(token);
		SoapHeader header = new SoapHeader(qName, element);
		return (header);
	}

	public AuthHeader getAuthHeader() {
		return authHeader;
	}

	public void setAuthHeader(AuthHeader authHeader) {
		this.authHeader = authHeader;
	}
}
