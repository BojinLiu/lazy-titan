package com.jd.common.interceptor;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;

import javax.xml.namespace.QName;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.binding.soap.SoapMessage;
import org.apache.cxf.binding.soap.saaj.SAAJInInterceptor;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Attachment;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.XMLMessage;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.log4j.Logger;
import org.w3c.dom.Element;

import com.jd.common.ws.AuthHeader;

public class CheckRESTHeaderIntercepter extends AbstractPhaseInterceptor<XMLMessage> {

	private Logger logger = Logger.getLogger(getClass());

	private AuthHeader authHeader;

	public CheckRESTHeaderIntercepter() {
		super(Phase.PRE_PROTOCOL);
		getAfter().add(SAAJInInterceptor.class.getName());
	}

	@Override
	public void handleMessage(XMLMessage message) throws Fault {
		if(authHeader == null){
			throw new IllegalArgumentException("authHeader must set!");
		}
		Map<String,ArrayList> header = (Map<String,ArrayList>)message.get(org.apache.cxf.message.Message.PROTOCOL_HEADERS);
		ArrayList tokenObjs = header.get(authHeader.getKey().toLowerCase());
		if (tokenObjs == null || tokenObjs.size() == 0) {
			throw new IllegalArgumentException("Token null! ");
		}
		String token = tokenObjs.get(0).toString();
		boolean b = checkTokenValue(token);
		if (!b) {
			throw new IllegalArgumentException("Token wrong! ");
		}
	}

	private boolean checkTokenValue(String token) {
		String tmp = authHeader.getTokenValue();
		if (StringUtils.isEmpty(tmp)) {
			return true;
		}
		if (StringUtils.isEmpty(token)) {
			return false;
		}
		return tmp.equals(token);
	}

	public void setAuthHeader(AuthHeader authHeader) {
		this.authHeader = authHeader;
	}
}
