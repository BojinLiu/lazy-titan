package com.jd.common.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.http.HttpException;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.apache.log4j.Logger;

public class HttpClientUtil {
	private static Logger log = Logger.getLogger(HttpClientUtil.class);

	public static String exec(String url, Map<String, String> params, Map<String, String> heads) throws HttpException {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		log.debug("create httppost:" + url);
		HttpUriRequest http = null;
		try {
			if (params != null) {
				http = postForm(url, params);
			} else {
				http = new HttpGet(url);
			}
			return invoke(httpclient, http, heads);
		} catch (Exception e) {
			throw new HttpException("http EXE error:" + url, e);
		}
	}

	private static String invoke(CloseableHttpClient httpclient, HttpUriRequest httpost, Map<String, String> heads) throws HttpException, IOException {
		if (heads != null) {
			for (String key : heads.keySet()) {
				httpost.setHeader(key, heads.get(key));
			}
		}
		CloseableHttpResponse response = null;
		try {
			response = httpclient.execute(httpost);
			return EntityUtils.toString(response.getEntity());
		} finally {
			if (response != null) {
				response.close();
			}
		}
	}

	private static HttpPost postForm(String url, Map<String, String> params) throws URISyntaxException, UnsupportedEncodingException {

		HttpPost httpost = new HttpPost(url);
		List<NameValuePair> nvps = new ArrayList<NameValuePair>();
		if (params != null) {
			for (String key : params.keySet()) {
				nvps.add(new BasicNameValuePair(key, params.get(key)));
			}
		}
		log.debug("set utf-8 form entity to httppost");
		httpost.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
		return httpost;
	}
}