package com.jd.common.util;

import java.io.IOException;

public class LogUtil {

	public static void main(String[] args) {
		System.out.println(LogUtil.trans(new Exception("ppppp")).replaceAll("\\s", "<br/>"));
	}
	/**
	 * 将异常信息打出来
	 * 
	 * @throws IOException
	 */
	public static String trans(Throwable e) {
		java.io.StringWriter sw = new java.io.StringWriter();
		try {
			e.printStackTrace(new java.io.PrintWriter(sw, true));
			return sw.toString().replaceAll("\\n", "<br/>");
		} finally {
			sw.flush();
			try {
				sw.close();
			} catch (IOException e1) {
				e1.printStackTrace();
			}
		}
	}
	/**
	 * 将异常信息打出来
	 * 
	 * @throws IOException
	 */
	public static String transHtml(Throwable e) {
		return trans(e).replaceAll("\\r\\n|\\n", "<br/>");
	}
}
