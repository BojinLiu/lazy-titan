package com.jd.common.springmvc.view;

import java.util.Map;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.json.MappingJacksonJsonView;

public class CustMappingJacksonJsonView extends MappingJacksonJsonView {
	@Override
	protected Object filterModel(Map<String, Object> model) {
		Map<?, ?> result = (Map<?, ?>) super.filterModel(model);
		Object obj = result.size() == 1 ? result.values().iterator().next() : result;
		if(obj instanceof ModelAndView){
			return ((ModelAndView)obj).getModelMap();
		} else {
			return obj;
		}
	}
}
