package com.jd.common.util;

import java.math.BigDecimal;
import java.util.regex.Pattern;

/**
 * Created with IntelliJ IDEA.
 * User: huangwei
 * Date: 13-11-21
 * Time: 下午4:17
 * To change this template use File | Settings | File Templates.
 */
public class NumberUtil {
    /**
     * Integer tryparse 转换失败后返回 0
     * @param value
     * @return
     */
    public static Integer intTryParse(String value){
        Integer parseResult = new Integer(0);
        try{
            parseResult = Integer.parseInt(value);
        }catch (NumberFormatException numberExp){

        }
        return parseResult;
    }

    /**
     * Long tryparse 转换失败后返回 0
     * @param value
     * @return
     */
    public static Long longTryParse(String value){
        Long parseResult = new Long(0);
        try{
            parseResult = Long.parseLong(value);
        }catch (NumberFormatException numberExp){

        }
        return parseResult;
    }

    /**
     * 是否为大于0的数字
     * @param str
     * @return
     */
    public static Boolean isnumber(String str){
        final String  regex = "^[1-9]\\d*$";
        Pattern p = Pattern.compile(regex);
        return p.matcher(str).matches();
    }

    /**
     * 是否为大于等于 0的数字
     * @param str
     * @return
     */
    public static Boolean isnumberIncludeZero (String str){
        final String  regex = "^[0-9]\\d*$";
        Pattern p = Pattern.compile(regex);
        return p.matcher(str).matches();
    }
}
