package com.jd.common.util;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.DigestUtils;

public class MacUtil {

	public static String mac(String in) {
		return new String(Base64.encodeBase64(DigestUtils.md5(in)));
	}
	
	public static void main(String[] args) throws Throwable {
		System.out.println(mac("admin"));
	}

}
