package com.jd.common.util;

import javax.script.Bindings;
import javax.script.Compilable;
import javax.script.CompiledScript;
import javax.script.ScriptContext;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import com.jd.common.domain.CustJsFun;

/**
 * author by http://www.bt285.cn/content.php?id=1196863
 */
public class ScriptUtil {
	/**
	 * 生成执行方法函数
	 * @param funcName
	 * @param funcStr
	 * @return
	 * @throws Exception 
	 */
	public static <T> CustJsFun<T> getFun(String funcName, String funcStr, Class<T> refType) throws Exception {
		if(funcStr.indexOf("_rs") != -1 || funcStr.indexOf("_jo") != -1 || funcStr.indexOf("_funcName") != -1){
			throw new Exception("函数体不能含有关键字[_rs、_jo、funcName]");
		}
		ScriptEngine engine = new ScriptEngineManager().getEngineByName("javascript");
		// CompiledScript可以将ScriptEngine解析一段脚本的结果存起来，方便多次调用。只要将ScriptEngine用Compilable接口强制转换后，调用compile(String
		// script)就返回了一个CompiledScript对象，要用的时候每次调用一下CompiledScript.eval()即可，一般适合用于js函数的使用。
		Compilable compilable = (Compilable) engine;
		String rootScript = funcStr + "(function(jss,rs){var jo=eval('('+jss+')');return eval(_funcName+'(jo,rs)');})(_jo,_rs)"; // 定义函数并调用
		CompiledScript rootFunction = compilable.compile(rootScript); // 解析编译脚本函数
		Bindings bindings = rootFunction.getEngine().createBindings(); // Local级别的Binding
		bindings.put("_funcName",funcName);
		rootFunction.getEngine().setBindings(bindings, ScriptContext.ENGINE_SCOPE);
		return new CustJsFun<T>(rootFunction);
	}
	/**
	 * 若返回值即自定义函数返回值
	 * @param <T>
	 * @param jObjectStr
	 * @param rs
	 * @param fun
	 * @return
	 * @throws ScriptException
	 */
	public static <T> T getResult(String jObjectStr, T rs, CustJsFun<T> fun) throws ScriptException {
		if(fun == null){
			return rs;
		}
		CompiledScript rf = fun.getRootFunction();
		Bindings bindings = rf.getEngine().getBindings(ScriptContext.ENGINE_SCOPE); // Local级别的Binding
		bindings.put("_rs", rs);
		bindings.put("_jo", jObjectStr);
		return (T)rf.eval(bindings);
	}
}