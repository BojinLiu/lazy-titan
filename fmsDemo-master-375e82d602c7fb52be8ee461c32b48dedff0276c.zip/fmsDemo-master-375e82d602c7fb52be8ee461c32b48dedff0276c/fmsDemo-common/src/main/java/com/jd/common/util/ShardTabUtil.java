package com.jd.common.util;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

public class ShardTabUtil {

	public static Integer getShareNum(String key, long shardNum) {
		CRC32 crc32 = new CRC32();
		try {
			crc32.update(key.toLowerCase().getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			return null;
		}
		return Integer.valueOf((int) (crc32.getValue() % shardNum));
	}

	public static List<Integer> getRunShareNums(int partitionId, int count, long shardNum) {
		List<Integer> nums = new ArrayList<Integer>();
		for (int i = 0; i < shardNum; i++) {
			if (i % count == partitionId) {
				nums.add(i);
			}
		}
		return nums;
	}

	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.SHORT_PREFIX_STYLE);
	}
}
