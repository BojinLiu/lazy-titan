package com.jd.common.util;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;

public abstract class CacheBase<T> {

	protected Logger logger = Logger.getLogger(getClass());
	protected LoadingCache<String, Object> localCache;

	private LoadingCache<String, Object> getCache() {
		if (localCache == null) {
			localCache = CacheBuilder.newBuilder().expireAfterWrite(getCacheTime(), TimeUnit.SECONDS).maximumSize(getMaxLength()).build(new CacheLoader<String, Object>() {
				public Object load(String key) throws IOException {
					return loadObj();
				}
			});
		}
		return localCache;
	}

	/**
	 * 通过查询初始化列表 方法名必须为public static boolean initByQuery() 设计到可手动刷新
	 * @return
	 */
	protected T getByCache(String key) {
		try {
			if (key == null) {
				return null;
			}
			if (resetCache()) {
				getCache().cleanUp();
				return null;
			}
			return (T) getCache().get(key);
		} catch (Throwable e) {
			logger.error("error", e);
		}
		return null;
	}

	/**
	 * @return
	 */
	protected void setByCache(final String key,
		T obj) {
		if (obj == null) {
			return;
		}
		try {
			getCache().put(key, obj);
		} catch (Throwable e) {
			logger.error("error", e);
		}
	}

	//key的最大数量
	protected abstract T loadObj();
	//key的最大数量
	protected abstract long getMaxLength();
	//是否重置缓存，可以动态配置
	protected abstract boolean resetCache();
	//缓存失效时间
	protected abstract long getCacheTime();
}
