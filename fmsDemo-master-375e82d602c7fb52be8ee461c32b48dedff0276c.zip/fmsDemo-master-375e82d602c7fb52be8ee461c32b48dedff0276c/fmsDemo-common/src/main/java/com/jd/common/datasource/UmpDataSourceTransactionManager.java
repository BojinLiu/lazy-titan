package com.jd.common.datasource;

import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.DefaultTransactionStatus;
import org.springframework.util.Assert;

import com.jd.ump.profiler.CallerInfo;
import com.jd.ump.profiler.proxy.Profiler;

public class UmpDataSourceTransactionManager extends DataSourceTransactionManager {

	private static final ThreadLocal<CallerInfo> holder = new ThreadLocal<CallerInfo>();
	private String umpAppName;
	private String keyPre;
	private String umpKey;

	@Override
	protected void doBegin(Object transaction,
		TransactionDefinition definition) {
		holder.set(Profiler.registerInfo(umpKey, umpAppName, true, true));
		super.doBegin(transaction, definition);
	}

	private void endUmp() {
		CallerInfo info = holder.get();
		if (info != null) {
			Profiler.registerInfoEnd(info);
		} else {
			logger.error("umpTransactionManagerCallerInfo is null");
		}
	}

	@Override
	protected void doResume(Object transaction,
		Object suspendedResources) {
		super.doResume(transaction, suspendedResources);
	}

	@Override
	protected void doCommit(DefaultTransactionStatus status) {
		super.doCommit(status);
		endUmp();
	}

	@Override
	protected void doRollback(DefaultTransactionStatus status) {
		super.doRollback(status);
		endUmp();
	}

	public void setUmpAppName(String umpAppName) {
		this.umpAppName = umpAppName;
	}

	public void setKeyPre(String keyPre) {
		this.keyPre = keyPre;
	}

	@Override
	public void afterPropertiesSet() {
		super.afterPropertiesSet();
		Assert.notNull(umpAppName, "umpAppName is null");
		Assert.notNull(keyPre, "keyPre is null");
		this.umpKey = this.umpAppName + "." + this.keyPre + ".transactionManager";
	}
}
