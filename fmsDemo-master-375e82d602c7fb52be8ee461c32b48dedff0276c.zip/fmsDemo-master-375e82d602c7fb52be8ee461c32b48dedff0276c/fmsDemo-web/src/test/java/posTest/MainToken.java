package posTest;

import com.jd.common.ws.AuthHeader;

public class MainToken {

	public static void main(String[] args) {
		AuthHeader ah = new AuthHeader();
		ah.setContent("123456");
		ah.setSeed("123456");
		System.out.println(ah.getTokenValue());
	}

}
