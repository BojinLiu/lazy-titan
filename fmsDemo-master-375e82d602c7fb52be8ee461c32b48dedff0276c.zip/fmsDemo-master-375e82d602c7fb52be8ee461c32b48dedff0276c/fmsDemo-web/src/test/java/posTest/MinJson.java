package posTest;

import java.io.IOException;
import java.util.HashMap;

import com.jd.common.util.JsonUtil;

public class MinJson {

	public static void main(String[] args) throws IOException {
		String str = "{\"ware\":\"铭聚布艺 软玻璃加厚PVC桌布防水防烫塑料台布餐桌垫茶几垫透明磨砂水晶板	多彩缤纷(厚度1.0mm）70cm*130c\"}";
//		str = "{\"ware\":\"铭聚布艺软玻璃加厚PVC桌布防水防烫塑料台布餐桌垫茶几垫透明磨砂水晶板\n多彩缤纷(厚度1.0mm）70cm*130c\"}";
		System.out.println("str1="+str);
		str = str.replaceAll("	", "\\\\t");
		HashMap<String, String> fromJson = new HashMap<String, String>();
//		fromJson.put("ware", "铭聚布艺 软玻璃加厚PVC桌布防水防烫塑料台布餐桌垫茶几垫透明磨砂水晶板	多彩缤纷(厚度1.0mm）70cm*130c");
//		System.out.println("str2="+fromJson);
//		str = JsonUtil.toJson(fromJson);
		System.out.println("json="+str);
//		str = JsonUtil.fromJson(str, String.class);
//		System.out.println("obj="+str);
		fromJson = JsonUtil.fromJson(str, HashMap.class);
		System.out.println("obj="+fromJson);
		//
		//System.out.println(replaceAll);
//		System.out.println(JsonUtil.fromJson(str, HashMap.class));
	}

}
