package com.jd.project.server.domain;

public class ServerException extends Exception {

	public ServerException(String string) {
		super(string);
	}

	public ServerException() {
		super();
	}

	public ServerException(String message, Throwable cause) {
		super(message, cause);
	}

	public ServerException(Throwable cause) {
		super(cause);
	}

}
