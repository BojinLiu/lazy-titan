package com.jd.project.custenum.domainTypeEnum;

import com.jd.common.mybatis.Convertable;

/**
 * 财务对账状态枚举
 */
@Convertable
public enum FinanceCheckEnum {

	READY(0, "没对账"), SUCCESS(1, "对账成功"), FAIL(2, "对账失败"), OTHER(3, "别的系统已对账"), INRECON(5, "对账中");// 运单对账状态

	private final Integer value;
	private final String text;

	private FinanceCheckEnum(Integer value, String text) {
		this.value = value;
		this.text = text;
	}

	/**
	 * @Convertable注释必须方法[value()]
	 * @return
	 */
	public Integer value() {
		return value;
	}

	public String getText() {
		return text;
	}

	public String toString() {
		return name() + ":" + getText() + "[" + value() + "]";
	}

	/**
	 * @Convertable注释必须方法[of]
	 * @param value
	 * @return
	 */
	public static FinanceCheckEnum of(final Integer value) {
		for (FinanceCheckEnum ot : values()) {
			if (ot.value().equals(value)) {
				return ot;
			}
		}
		return null;
	}
}
