package com.jd.project.controller;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.jd.common.BaseControl;
import com.jd.common.util.JsonUtil;

@Controller
@RequestMapping("/msgs")
public class MessageSourceController extends BaseControl{

	@ResponseBody
	@RequestMapping("/getLocaljs.json")
	public String getLocaljs() throws IOException {
		return "function getMessage(key) {var localMag = " + JsonUtil.toJson(messageSource.getLocalPro()) + ";if(localMag[key]){return localMag[key];} return 'not contain thisKey';}";
	}
	
}
