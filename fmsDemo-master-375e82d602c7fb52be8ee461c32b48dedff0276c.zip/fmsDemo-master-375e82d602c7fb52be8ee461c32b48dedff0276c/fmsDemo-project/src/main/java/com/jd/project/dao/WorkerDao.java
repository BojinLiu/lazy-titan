package com.jd.project.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.jd.project.domain.CustWorker;

public interface WorkerDao {
	public CustWorker selectByKey(@Param("workerId")long workerId);
	public int saveWorker(CustWorker worker);
	public int update(CustWorker worker);
	public List<CustWorker> getPageDateByPara(Map<String, Object> paraMap);
	public int getPageCountByPara(Map<String, Object> paraMap);
	public Map<String, Long> getMaxMin(@Param("tabIndex") long tabIndex);
	public int doDeleteExpiredWorker(@Param("tabIndex") long tabIndex, @Param("maxNum") long maxNum, @Param("limitNum") long limitNum);
}
