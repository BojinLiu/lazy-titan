package com.jd.project.domain;


import com.jd.common.domain.BasePojo;

public class WarningInfo extends BasePojo {

	private String name;
	private String phoneNum;
	private String mailNum;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhoneNum() {
		return phoneNum;
	}

	public void setPhoneNum(String phoneNum) {
		this.phoneNum = phoneNum;
	}

	public String getMailNum() {
		return mailNum;
	}

	public void setMailNum(String mailNum) {
		this.mailNum = mailNum;
	}
}
