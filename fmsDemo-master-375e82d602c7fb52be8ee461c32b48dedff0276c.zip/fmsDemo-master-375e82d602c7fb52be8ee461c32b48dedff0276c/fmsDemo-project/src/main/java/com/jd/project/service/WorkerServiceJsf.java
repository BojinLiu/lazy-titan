package com.jd.project.service;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import com.jd.project.dao.WorkerDao;
import com.jd.project.domain.CustWorker;
import com.jd.project.server.FmTest;
import com.jd.project.server.domain.ServerException;
import com.jd.project.server.domain.WorkerJsf;

public class WorkerServiceJsf implements FmTest {

	protected Logger log = Logger.getLogger(getClass());
	
	@Resource
	private WorkerDao workerDao;

	@Override
	public WorkerJsf getWk(long workerId) throws ServerException{
		try {
			CustWorker w = workerDao.selectByKey(workerId);
			if (w == null) {
				return null;
			}
			WorkerJsf rs = new WorkerJsf();
			rs.setWorkerId(w.getWorkerId());
			rs.setWorkerTypeCode(w.getWorkerTypeCode());
			return rs;
		} catch (Throwable e) {
			log.error("getWk error:"+workerId, e);
			throw new ServerException("异常，请重试");
		}
	}
}
