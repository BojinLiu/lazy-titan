package com.jd.project.controller;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.jd.common.BaseControl;
import com.jd.common.demo.IRESTDemo;
import com.jd.common.demo.webbean.WebDemoItem;
import com.jd.common.util.ExcelUtil;
import com.jd.common.util.ExportExcelUtil;
import com.jd.common.util.JdDateUtil;
import com.jd.common.util.PaginatedList;
import com.jd.common.util.StringUtil;
import com.jd.cwbase.worker.tpyeEnum.WorkerStatusEnum;
import com.jd.project.domain.CustWorker;
import com.jd.project.service.WorkerService;

@Controller
@RequestMapping("/worker")
public class WorkerController extends BaseControl {

	@Resource
	private WorkerService workerService;
	
	@Resource(name="restClient")
	private IRESTDemo restClient;
	

	/**
	 * 获取worker列表页面
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/workerPage")
	public void worker(Model model) {
		//国际化
		//java使用方式
		messageSource.getMessage("search.applyInfo.exits.alert", "11111");
		//vm使用该方式
		messageSource.getMessage("search.applyInfo.exits.alert", "11111");
		//js使用方式
		//getMessage("search.applyInfo.exits.alert")
		model.addAttribute("workerStatusEnum", WorkerStatusEnum.values());
	}
	
	/**
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/testRest.json")
	public void testRest(Model model) {
		WebDemoItem bean = restClient.getBean(1000, "para");
		model.addAttribute("bean", bean);
	}

	private Map<String, Object> initPara(String workerTypeCode,
			Long workerId,
			String appCode,
			String appLogo,
			String refOreders,
			Integer workerStatus,
			Date createTime,
			String msg,
			String sidx,
			String sord) throws ParseException {
		Map<String, Object> para = new HashMap<String, Object>();
		para.put("workerId", workerId);
		para.put("appCode", appCode);
		para.put("workerTypeCode", workerTypeCode);
		para.put("appLogo", appLogo);
		para.put("refOreders", refOreders);
		para.put("workerStatus", workerStatus);
		if (createTime != null) {
			para.put("startTime", createTime);
			para.put("endTime", JdDateUtil.getNextDay(createTime));
		}
		para.put("msg", msg);
		para.put("sord", "desc".equalsIgnoreCase(sord) ? "DESC" : "ASC");
		if ("workerId".equals(sidx)) {
			para.put("sidx", "WORKER_ID");
		} else if ("workerTypeName".equals(sidx)) {
			para.put("sidx", "WORKER_TYPE_CODE");
		} else if ("wtypeText".equals(sidx)) {
			para.put("sidx", "WTYPE");
		} else if ("createTime".equals(sidx)) {
			para.put("sidx", "CREATE_TIME");
		} else {
			para.put("sidx", "WORKER_ID");
		}
		return para;
	}

	/**
	 * 获取worker列表页面
	 * 
	 * @return
	 * @throws Exception
	 */
	@RequestMapping("/doWorkerVm")
	public String doWorkerVm(@RequestParam(value="workerTypeCode", required = false) String workerTypeCode,
			@RequestParam(value="workerId", required = false) Long workerId,
			@RequestParam(value="appCode", required = false) String appCode,
			@RequestParam(value="appLogo", required = false) String appLogo,
			@RequestParam(value="refOreders", required = false) String refOreders,
			@RequestParam(value="workerStatus", required = false) Integer workerStatus,
			@RequestParam(value="createTime", required = false) Date createTime,
			@RequestParam(value="msg", required = false) String msg,
			@RequestParam(value="sidx", required = false) String sidx,
			@RequestParam(value="sord", required = false) String sord,
			@RequestParam(value="page", required = false, defaultValue = "1") int page,
			@RequestParam(value="pageSize", required = false, defaultValue = "20") int pageSize,
			Model model) {
		model.addAttribute("workerStatusEnum", WorkerStatusEnum.values());
		try {
			if (page <= 0) {
				page = 1;
			}
			if (pageSize <= 0) {
				page = 20;
			}
			Map<String, Object> para = initPara(workerTypeCode, workerId, appCode, appLogo, refOreders, workerStatus, createTime, msg, sidx, sord);
			model.addAttribute("para", para);
			PaginatedList<CustWorker> datas = workerService.doWorker(page, pageSize, para);
			model.addAttribute("datas", datas);
		} catch (Exception e) {
			log.error("doWorkerVm", e);
		}
		return "/worker/workerPage";
	}

	@RequestMapping("/doWorkerExcel")
	public void doWorkerExcel(@RequestParam(value="workerTypeCode", required = false) String workerTypeCode,
			@RequestParam(value="workerId", required = false) Long workerId,
			@RequestParam(value="appCode", required = false) String appCode,
			@RequestParam(value="appLogo", required = false) String appLogo,
			@RequestParam(value="refOreders", required = false) String refOreders,
			@RequestParam(value="workerStatus", required = false) Integer workerStatus,
			@RequestParam(value="createTime", required = false) Date createTime,
			@RequestParam(value="msg", required = false) String msg,
			@RequestParam(value="sidx", required = false) String sidx,
			@RequestParam(value="sord", required = false) String sord,
			@RequestParam(value="page", required = false, defaultValue = "1") int page,
			@RequestParam(value="pageSize", required = false, defaultValue = "20") int pageSize,
			Model model,
			HttpServletRequest request,
			HttpServletResponse response) {
		if (page <= 0) {
			page = 1;
		}
		if (pageSize <= 0) {
			page = 20;
		}
		Map<String, Object> para;
		try {
			para = initPara(workerTypeCode, workerId, appCode, appLogo, refOreders, workerStatus, createTime, msg, sidx, sord);
			PaginatedList<CustWorker> ds = workerService.doWorker(page, pageSize, para);
			Map<String, List<CustWorker>> beans = new HashMap<String, List<CustWorker>>();
			beans.put("pageInfo", ds);
			ExportExcelUtil.exportExcel(request, response, "WEB-INF/excelTemplate/demo.xls", "下载样例.xls", beans);
		} catch (ParseException e) {
			log.error("doWorkerExcel:" + workerTypeCode, e);
		}
	}

	/**
	 * 上传
	 * 
	 * @param file
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/upload.json")
	public void upload(@RequestParam MultipartFile file, Model model) {
		model.addAttribute("success", false);
		model.addAttribute("repeat", false);
		try {
			String[][] readFromFile = ExcelUtil.readFromFile(file, 20, 300000);
			System.out.println(file.getName());
			model.addAttribute("success", true);
		} catch (Exception e) {
			log.error("upload异常:" + StringUtil.toPath(file.getName(), String.valueOf(file.getSize())), e);
			model.addAttribute("errorMsg", e.getMessage());
		}
	}
	/**
	 * un上传
	 * 
	 * @param file
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/unUpload.json")
	public void unUpload(@RequestParam String fileName, Model model) {
		model.addAttribute("success", false);
		model.addAttribute("errorMsg", "");
		try {
			System.out.println(fileName);
			model.addAttribute("success", true);
		} catch (Exception e) {
			log.error("unUpload异常:" + fileName, e);
			model.addAttribute("errorMsg", e.getMessage());
		}
	}

	@RequestMapping(value = "/select.json")
	public void select(long workerId, Model model) {
		model.addAttribute("success", false);
		try {
			model.addAttribute("info", workerService.select(workerId));
			model.addAttribute("success", true);
			model.addAttribute("msg", "ok");
		} catch (Exception e) {
			log.error("select异常:" + StringUtil.toObjString(workerId), e);
			model.addAttribute("errorMsg", e.getMessage());
		}
	}

	@RequestMapping(value = "/save.json")
	public void save(String workerTypeCode, String appLogo, Model model) {
		model.addAttribute("success", false);
		try {
			Date now = new Date();
			CustWorker worker = new CustWorker();
			worker.setAppCode("appCode");
			worker.setWorkerTypeCode(workerTypeCode);
			worker.setAppLogo(appLogo);
			worker.setFailMaxNum(100);
			worker.setWorkerStatus(1);
			worker.setPartitionId(1);
			worker.setCreateTime(now);
			worker.setUpdateTime(now);
			model.addAttribute("success", workerService.save(worker));
			model.addAttribute("msg", "ok");
		} catch (Exception e) {
			log.error("save异常:" + StringUtil.toObjString(workerTypeCode, appLogo), e);
			model.addAttribute("errorMsg", e.getMessage());
		}
	}
	
	@RequestMapping(value = "/batchsave.json")
	public void batchsave(@RequestBody List<String> pojos, Model model) {
		model.addAttribute("success", false);
		try {
			System.out.println(pojos);
			model.addAttribute("success", true);
			model.addAttribute("msg", "ok");
		} catch (Exception e) {
			log.error("batchsave异常:" + StringUtil.toObjString(pojos), e);
			model.addAttribute("errorMsg", e.getMessage());
		}
	}

	@RequestMapping(value = "/update.json")
	public void update(long workerId, String workerTypeCode, String appLogo, Model model) {
		model.addAttribute("success", false);
		try {
			Date now = new Date();
			CustWorker worker = new CustWorker();
			worker.setWorkerId(workerId);
			worker.setAppCode("appCode");
			worker.setWorkerTypeCode(workerTypeCode);
			worker.setAppLogo(appLogo);
			worker.setFailMaxNum(100);
			worker.setOldWorkerStatus(1);
			worker.setWorkerStatus(1);
			worker.setPartitionId(1);
			worker.setCreateTime(now);
			worker.setUpdateTime(now);
			model.addAttribute("success", workerService.update(worker));
			model.addAttribute("msg", "ok");
		} catch (Exception e) {
			log.error("update异常:" + StringUtil.toObjString(workerTypeCode, appLogo), e);
			model.addAttribute("errorMsg", e.getMessage());
		}
	}
}
