package com.jd.project.domain;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.CRC32;

import com.jd.cwbase.worker.domain.Worker;

public class CustWorker extends Worker {

	private String appCode;
	private long useTime;
	private static long shardNum = 100;

	public static Integer getShareNum(String key) {
		CRC32 crc32 = new CRC32();
		try {
			crc32.update(key.toLowerCase().getBytes("UTF-8"));
		} catch (UnsupportedEncodingException e) {
			return null;
		}
		return Integer.valueOf((int) (crc32.getValue() % CustWorker.shardNum));
	}

	public static List<Integer> getRunShareNums(int partitionId, int count) {
		List<Integer> nums = new ArrayList<Integer>();
		for (int i = 0; i < CustWorker.shardNum; i++) {
			if (i % count == partitionId) {
				nums.add(i);
			}
		}
		return nums;
	}

	public Integer getTabIndex() {
		return getShareNum(super.getWorkerTypeCode());
	}

	public String getAppCode() {
		return appCode;
	}

	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}

	public long getUseTime() {
		return useTime;
	}

	public void setUseTime(long useTime) {
		this.useTime = useTime;
	}

}
