package com.jd.project.server.domain;

public class WorkerJsf {

	private Long workerId;
	private String workerTypeCode;
	
	public Long getWorkerId() {
		return workerId;
	}
	public void setWorkerId(Long workerId) {
		this.workerId = workerId;
	}
	public String getWorkerTypeCode() {
		return workerTypeCode;
	}
	public void setWorkerTypeCode(String workerTypeCode) {
		this.workerTypeCode = workerTypeCode;
	}
}
