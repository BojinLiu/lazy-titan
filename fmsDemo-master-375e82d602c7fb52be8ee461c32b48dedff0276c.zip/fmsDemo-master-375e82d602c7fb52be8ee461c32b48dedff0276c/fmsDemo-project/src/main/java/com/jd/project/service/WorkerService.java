package com.jd.project.service;

import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Component;

import com.jd.common.domain.MyPaginatedArrayList;
import com.jd.common.util.PaginatedList;
import com.jd.project.dao.WorkerDao;
import com.jd.project.domain.CustWorker;

@Component("workerService")
public class WorkerService {

	@Resource
	private WorkerDao workerDao;

	public PaginatedList<CustWorker> doWorker(int page, int pageSize, Map<String, Object> paraMap) {
		PaginatedList<CustWorker> pls = new MyPaginatedArrayList<CustWorker>(page, pageSize);
		paraMap.put("startNum", pls.getStartRow());
		paraMap.put("rows", pls.getPageSize());
		pls.setTotalItem(workerDao.getPageCountByPara(paraMap));
		if(pls.getTotalItem() > 0){
			pls.addAll(workerDao.getPageDateByPara(paraMap));
		}
		return pls;
	}

	public boolean save(CustWorker worker) {
		return 1 == workerDao.saveWorker(worker);
	}

	public boolean update(CustWorker worker) {
		return 1 == workerDao.update(worker);
	}

	public CustWorker select(long workerId) {
		return workerDao.selectByKey(workerId);
	}
}
