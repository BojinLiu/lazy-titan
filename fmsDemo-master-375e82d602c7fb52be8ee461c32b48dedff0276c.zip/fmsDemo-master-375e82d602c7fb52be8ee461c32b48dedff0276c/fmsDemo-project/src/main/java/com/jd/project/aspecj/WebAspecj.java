package com.jd.project.aspecj;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;

import com.jd.common.util.CacheBase;

@Aspect
public class WebAspecj extends CacheBase {

	@Around(value = "execution(* com.jd.common.rpc.dep.DeptWebServiceSoap.*(java.lang.String)) && args(pin)", argNames = "pin")
	public Object depWebCache(ProceedingJoinPoint pjp, String pin) throws Throwable {
		// metrics监控
		Object object = null;
		try {
			String pjps = pjp.getSignature().toShortString();
			String key = pjps + pin;
			if (pjps.indexOf("DeptWebService.getUserByName") != -1 || pjps.indexOf("DeptWebService.resourceNames") != -1) {
				object = getByCache(key);
				if (object != null) {
					return object;
				} else {
					object = pjp.proceed();
					if (object != null) {
						setByCache(key, object);
					}
					logger.info("key[" + key + "] not hit");
				}
			}
			return object;
		} catch (Throwable e) {
			throw e;
		}
	}

	public long getMaxLength() {
		return 100000;
	}

	public boolean resetCache() {
		return false;
	}

	@Override
	protected long getCacheTime() {
		return 86400;
	}

	@Override
	protected Object loadObj() {
		return null;
	}
}
