package com.jd.project.custenum.constantEnum;

/**
 * 
 */
public enum WorkerEnum {

	TEST_CYL("testCyl", "测试循环任务"), TEST_TASK("testTask", "测试自驱动任务");

	private final String workerTypeCode;
	private final String workerTypeName;

	private WorkerEnum(String workerTypeCode, String workerTypeName) {
		this.workerTypeCode = workerTypeCode;
		this.workerTypeName = workerTypeName;
	}

	public String getWorkerTypeCode() {
		return workerTypeCode;
	}

	public String getWorkerTypeName() {
		return workerTypeName;
	}

	public static WorkerEnum of(String workerTypeCode) {
		if (workerTypeCode != null) {
			for (WorkerEnum ot : values()) {
				if (ot.getWorkerTypeCode().equals(workerTypeCode)) {
					return ot;
				}
			}
		}
		return null;
	}
}
