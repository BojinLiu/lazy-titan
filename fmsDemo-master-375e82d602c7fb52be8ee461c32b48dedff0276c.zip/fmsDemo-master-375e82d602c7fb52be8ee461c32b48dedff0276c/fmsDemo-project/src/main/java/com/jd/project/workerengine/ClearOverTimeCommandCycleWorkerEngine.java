package com.jd.project.workerengine;

import javax.annotation.Resource;

import com.jd.common.util.StringUtil;
import com.jd.cwbase.worker.domain.WorkerException;
import com.jd.cwbase.worker.domain.WorkerResult;
import com.jd.cwbase.worker.domain.WorkerType;
import com.jd.cwbase.worker.workUtil.CycleWorkerEngine;
import com.jd.cwbase.worker.workUtil.WorkerQuartzUtil;
import com.jd.project.domain.WarningInfo;
import com.jd.project.service.WorkerService;

public class ClearOverTimeCommandCycleWorkerEngine extends CycleWorkerEngine {

	@Resource
	private WorkerService workerService;

	@Override
	public String getWorkerTypeCode() {
		return "clearOverTimeCommand";
	}

	@Override
	protected WorkerResult executeWorker(Integer p) throws WorkerException {
		WorkerResult wr = new WorkerResult(false, "");
		try {
			WarningInfo todo = new WarningInfo();
			todo.setName("todoName");
			WorkerQuartzUtil.getWorkerEngine("testTask").createWorker(todo);
			wr.setSuccess(true);
			wr.setMsg("成功*条/失败*条");
		} catch (Exception e) {
			wr.setMsg(e.getMessage());
			logger.error(StringUtil.toPath("error:", getWorkerTypeCode(), String.valueOf(p)), e);
		}
		return wr;
	}
	
	@Override
	protected void custDefaultWorkerType(WorkerType wt) {
		wt.setWorkerTypeName("清空超时命令");
	}

}
