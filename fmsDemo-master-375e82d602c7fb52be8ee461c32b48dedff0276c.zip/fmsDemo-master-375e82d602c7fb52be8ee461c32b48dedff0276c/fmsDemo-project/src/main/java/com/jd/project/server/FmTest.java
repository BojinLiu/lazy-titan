package com.jd.project.server;

import com.jd.project.server.domain.ServerException;
import com.jd.project.server.domain.WorkerJsf;

public interface FmTest {

	public WorkerJsf getWk(long workerId) throws ServerException;
}
