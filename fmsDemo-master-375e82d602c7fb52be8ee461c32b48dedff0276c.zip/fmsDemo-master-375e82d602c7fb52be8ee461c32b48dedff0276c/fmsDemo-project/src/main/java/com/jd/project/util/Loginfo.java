package com.jd.project.util;

import com.jd.common.web.LoginContext;

public class Loginfo {

	public static String getPin() {
		return LoginContext.getLoginContext().getPin();
	}
}
