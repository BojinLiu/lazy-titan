package com.jd.project.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.jd.common.BaseControl;

@Controller
@RequestMapping("/")
public class IndexController extends BaseControl {

	@RequestMapping("/outLine")
	public void outLine(Model model) {
	}
	@RequestMapping("/inLine")
	public void inLine(Model model) {
	}

}
