package com.jd.project.workerengine;

import com.jd.cwbase.worker.domain.Worker;
import com.jd.cwbase.worker.domain.WorkerException;
import com.jd.cwbase.worker.domain.WorkerResult;
import com.jd.cwbase.worker.mySqlmpl.engine.MysqlTaskWorkerEngine;
import com.jd.cwbase.worker.mySqlmpl.operare.MysqlTaskWorkerOperate;
import com.jd.cwbase.worker.workUtil.WorkerQuartzUtil;
import com.jd.project.domain.WarningInfo;

/**
 * 		//此处为 事件触发生成该任务样例代码
 *		WarningInfo todo = new WarningInfo();
 *		todo.setName("todoName");
 *		WorkerQuartzUtil.getWorkerEngine("testTask").createWorker(todo);
 * @author liushenbao
 */
public class TestTaskWorkerEngine extends MysqlTaskWorkerEngine<WarningInfo> {

	@Override
	public String getWorkerTypeCode() {
		return "testTask";
	}
	
	@Override
	protected Worker createInitWorker(WarningInfo info) {
		Worker w = new Worker();
		w.setRefOreders(info.getName());
		return w;
	}
	
	@Override
	protected WorkerResult executeWorker(WarningInfo info) throws WorkerException {
		WorkerResult wr = new WorkerResult();
		try {
			//to do
			System.out.println("testTask run。。。。。。。。。。。。。。。。。。。。。。。。");
			wr.setSuccess(true);
			wr.setMsg(info.getName());
		} catch (Exception e) {
			wr.setMsg(e.getMessage());
			logger.error(info.toString(), e);
		}
		return wr;
	}
	
	public static void main(String[] args) {
		String printTabSql = new MysqlTaskWorkerOperate(5, "cust_worker").printTabSql();
		System.out.println(printTabSql);
	}
}
