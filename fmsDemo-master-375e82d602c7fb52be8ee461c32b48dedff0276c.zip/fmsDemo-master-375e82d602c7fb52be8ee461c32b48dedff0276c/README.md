财务研发部基础项目模板
===================
[![](https://img.shields.io/badge/JD.COM-%E8%B4%A2%E5%8A%A1%E7%A0%94%E5%8F%91%E9%83%A8-red.svg)](http://git.jd.com/fm-group)

# 主要功能
财务研发部基础项目模板，集成常用工具类，帮助新入职员工快速了解财务研发项目基础结构和工具类的使用。

本项目集成[代码小丽]()，一款根据数据库表自动生成代码结构的工具，[点此](http://fm-share.jd.com/rest/share/info/52)查看文档

# 工具类介绍

- AmountUtil:金额工具类 
- ApplicationContextUtil:spring句柄工具类
- Arith:金额计算 
- CacheBase:本地缓存实现基类<带过期配置 
- CheckUtil:校验工具类
- DesUtil:加解密工具类
- ExcelUtil:读取excel工具类
- ExportExcelUtil:导出excel工具类
- FileRunningUtil:通过修改文件名后续标志预占读取文件工具类
- FtpUtil:ftp工具类
- HttpClientUtil:http访问工具类
- IpUtil:获取本机ip 
- JdDateUtil:时间工具类
- JsonUtil:JSON工具类
- JxlsCopyUtil:？？？？
- ListUtil:列表筛选工具类/包括筛选和排序
- LogUtil:exception转换html输出
- MacUtil:签名工具类
- MoneyFormatUtil:金额格式换
- NumberUtil:数字类工具类
- ProjectCheckUtil:工程校验工具类
- PropertiesUtil:？？？？
- ResponseUtil:html的response的ContentType获取工具类
- RowsspanUtil:页面td展示rowspan计算工具类
- ScriptUtil:javascript的加载运行工具类
- SFtpUtil:SFTP工具类
- ShardTabUtil:分表序列号获取工具类
- SocketUtil:socket连接工具类
- StringUtil:StringUtil
- SystemInfoUtil:系统jvm信息
- SystemUtil:获取系统信息<操作系统>
- TarUtil:tar压缩和解压
- UmpUtil:添加ump的jvm和system监控配置工具类
- ViewUtil:页面枚举直接转换为select工具类
- ZipUtils:zip压缩和解压工具类